import SwiftUI

struct SearchBarView: View {
    @StateObject var searchBarViewModel = SearchBarViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack {
                                HStack {
                                    Image("img_wifi")
                                        .resizable()
                                        .frame(width: getRelativeWidth(18.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(271.0))
                                    Image("img_cellular")
                                        .resizable()
                                        .frame(width: getRelativeWidth(14.0),
                                               height: getRelativeWidth(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                    Image("img_battery")
                                        .resizable()
                                        .frame(width: getRelativeWidth(9.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(9.0))
                                    Image("img_time")
                                        .resizable()
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(10.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(6.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                }
                                .onTapGesture {
                                    searchBarViewModel.nextScreen = "HomeView"
                                }
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .background(ColorConstants.Green200)
                                HStack {
                                    Image("img_arrowleft_black_900")
                                        .resizable()
                                        .frame(width: getRelativeWidth(10.0),
                                               height: getRelativeHeight(18.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                    Text(StringConstants.kLblSearchBar)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(20.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(98.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(15.0))
                                }
                                .frame(width: getRelativeWidth(123.0),
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(11.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                            }
                        }
                        .frame(width: UIScreen.main.bounds.width - 20,
                               height: getRelativeHeight(72.0), alignment: .leading)
                        .background(ColorConstants.Green200)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(72.0),
                           alignment: .leading)
                    VStack {
                        ZStack(alignment: .center) {
                            Text(StringConstants.kLblScanYourTrash)
                                .font(FontScheme.kSquadaOneRegular(size: getRelativeHeight(25.0)))
                                .fontWeight(.regular)
                                .foregroundColor(ColorConstants.Gray800)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.center)
                                .frame(width: getRelativeWidth(58.0),
                                       height: getRelativeHeight(99.0), alignment: .center)
                            VStack(alignment: .leading, spacing: 0) {
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(58.0),
                                           height: getRelativeHeight(8.0), alignment: .leading)
                                    .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                               bottomLeft: 4.0, bottomRight: 4.0)
                                            .fill(ColorConstants.Bluegray300))
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(58.0),
                                           height: getRelativeHeight(8.0), alignment: .leading)
                                    .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                               bottomLeft: 4.0, bottomRight: 4.0)
                                            .fill(ColorConstants.Bluegray300))
                                    .padding(.top, getRelativeHeight(24.0))
                            }
                            .frame(width: getRelativeWidth(58.0), height: getRelativeHeight(40.0),
                                   alignment: .center)
                            .padding(.bottom, getRelativeHeight(33.18))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(58.0), height: getRelativeHeight(99.0),
                               alignment: .center)
                        .padding(.horizontal, getRelativeWidth(23.0))
                        HStack {
                            Image("img_searchbuttoni")
                                .resizable()
                                .frame(width: getRelativeWidth(38.0),
                                       height: getRelativeHeight(25.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(17.0))
                                .padding(.bottom, getRelativeHeight(16.0))
                                .padding(.leading, getRelativeWidth(10.0))
                                .onTapGesture {
                                    searchBarViewModel.nextScreen = "ResultView"
                                }
                            ZStack(alignment: .leading) {
                                Text(StringConstants.kMsgSearchForYour)
                                    .font(FontScheme
                                        .kRedHatTextMedium(size: getRelativeHeight(17.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Gray600)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(166.0),
                                           height: getRelativeHeight(23.0), alignment: .topLeading)
                                    .padding(.trailing, getRelativeWidth(32.0))
                                Button(action: {}, label: {
                                    HStack(spacing: 0) {
                                        Text(StringConstants.kMsgSearchForYour)
                                            .font(FontScheme
                                                .kInterRegular(size: getRelativeHeight(16.0)))
                                            .fontWeight(.regular)
                                            .padding(.trailing, getRelativeWidth(24.0))
                                            .padding(.leading, getRelativeWidth(15.0))
                                            .padding(.vertical, getRelativeHeight(10.0))
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(198.0),
                                                   height: getRelativeHeight(40.0),
                                                   alignment: .topLeading)
                                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                                       bottomLeft: 4.0,
                                                                       bottomRight: 4.0)
                                                    .fill(ColorConstants.LightGreen100))
                                    }
                                })
                                .frame(width: getRelativeWidth(198.0),
                                       height: getRelativeHeight(40.0), alignment: .topLeading)
                                .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                           bottomLeft: 4.0, bottomRight: 4.0)
                                        .fill(ColorConstants.LightGreen100))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(198.0), height: getRelativeHeight(40.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(10.0))
                            .padding(.bottom, getRelativeHeight(8.0))
                            .padding(.leading, getRelativeWidth(12.0))
                        }
                        .frame(width: getRelativeWidth(329.0), height: getRelativeHeight(58.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 10.0, topRight: 10.0, bottomLeft: 10.0,
                                                   bottomRight: 10.0)
                                .fill(ColorConstants.LightGreen100))
                        .padding(.top, getRelativeHeight(9.0))
                        .padding(.horizontal, getRelativeWidth(23.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(166.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(18.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kLblBrowse)
                            .font(FontScheme.kRedHatTextMedium(size: getRelativeHeight(17.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Bluegray900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(58.0), height: getRelativeHeight(23.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(33.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(23.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(7.0))
                    VStack {
                        ZStack(alignment: .leading) {
                            VStack {
                                Text(StringConstants.kLblGlass)
                                    .font(FontScheme
                                        .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Teal50)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(62.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(48.0))
                                    .padding(.bottom, getRelativeHeight(49.0))
                                    .padding(.horizontal, getRelativeWidth(47.0))
                            }
                            .frame(width: getRelativeWidth(158.0), height: getRelativeHeight(122.0),
                                   alignment: .trailing)
                            .background(RoundedCorners(topLeft: 12.0, topRight: 12.0,
                                                       bottomLeft: 12.0, bottomRight: 12.0)
                                    .fill(ColorConstants.Bluegray300))
                            .padding(.leading, getRelativeWidth(171.0))
                            VStack(alignment: .leading, spacing: 0) {
                                HStack {
                                    VStack {
                                        Text(StringConstants.kLblPaper)
                                            .font(FontScheme
                                                .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                            .fontWeight(.medium)
                                            .foregroundColor(ColorConstants.Teal50)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(59.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.top, getRelativeHeight(48.0))
                                            .padding(.bottom, getRelativeHeight(49.0))
                                            .padding(.horizontal, getRelativeWidth(49.0))
                                    }
                                    .frame(width: getRelativeWidth(158.0),
                                           height: getRelativeHeight(122.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 12.0, topRight: 12.0,
                                                               bottomLeft: 12.0, bottomRight: 12.0)
                                            .fill(ColorConstants.Bluegray300))
                                    Spacer()
                                    VStack {
                                        Text(StringConstants.kLblCan)
                                            .font(FontScheme
                                                .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                            .fontWeight(.medium)
                                            .foregroundColor(ColorConstants.Teal50)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(39.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.top, getRelativeHeight(48.0))
                                            .padding(.bottom, getRelativeHeight(49.0))
                                            .padding(.horizontal, getRelativeWidth(59.0))
                                    }
                                    .frame(width: getRelativeWidth(158.0),
                                           height: getRelativeHeight(122.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 12.0, topRight: 12.0,
                                                               bottomLeft: 12.0, bottomRight: 12.0)
                                            .fill(ColorConstants.Bluegray300))
                                }
                                .frame(width: getRelativeWidth(329.0),
                                       height: getRelativeHeight(122.0), alignment: .leading)
                                VStack {
                                    Text(StringConstants.kLblPlastic2)
                                        .font(FontScheme
                                            .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Teal50)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(78.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(48.0))
                                        .padding(.bottom, getRelativeHeight(49.0))
                                        .padding(.horizontal, getRelativeWidth(39.0))
                                }
                                .frame(width: getRelativeWidth(158.0),
                                       height: getRelativeHeight(122.0), alignment: .leading)
                                .background(RoundedCorners(topLeft: 12.0, topRight: 12.0,
                                                           bottomLeft: 12.0, bottomRight: 12.0)
                                        .fill(ColorConstants.Bluegray300))
                                .padding(.top, getRelativeHeight(12.0))
                                .padding(.trailing, getRelativeWidth(10.0))
                                HStack {
                                    VStack {
                                        Text(StringConstants.kLblMetal)
                                            .font(FontScheme
                                                .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                            .fontWeight(.medium)
                                            .foregroundColor(ColorConstants.Teal50)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(60.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.top, getRelativeHeight(48.0))
                                            .padding(.bottom, getRelativeHeight(49.0))
                                            .padding(.horizontal, getRelativeWidth(48.0))
                                    }
                                    .frame(width: getRelativeWidth(158.0),
                                           height: getRelativeHeight(122.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 12.0, topRight: 12.0,
                                                               bottomLeft: 12.0, bottomRight: 12.0)
                                            .fill(ColorConstants.Bluegray300))
                                    Spacer()
                                    VStack {
                                        Text(StringConstants.kLblCompostable)
                                            .font(FontScheme
                                                .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                            .fontWeight(.medium)
                                            .foregroundColor(ColorConstants.Teal50)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(139.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.vertical, getRelativeHeight(52.0))
                                            .padding(.horizontal, getRelativeWidth(9.0))
                                    }
                                    .frame(width: getRelativeWidth(158.0),
                                           height: getRelativeHeight(122.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 12.0, topRight: 12.0,
                                                               bottomLeft: 12.0, bottomRight: 12.0)
                                            .fill(ColorConstants.Bluegray300))
                                }
                                .frame(width: getRelativeWidth(329.0),
                                       height: getRelativeHeight(122.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(12.0))
                            }
                            .frame(width: getRelativeWidth(329.0), height: getRelativeHeight(390.0),
                                   alignment: .leading)
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(329.0), height: getRelativeHeight(390.0),
                               alignment: .center)
                        .padding(.horizontal, getRelativeWidth(23.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(390.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(14.0))
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLbl5)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(1.0))
                                Text(StringConstants.kLblHome)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(27.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .onTapGesture {
                                searchBarViewModel.nextScreen = "HomeView"
                            }
                            .frame(width: getRelativeWidth(27.0), height: getRelativeHeight(38.0),
                                   alignment: .top)
                            .padding(.vertical, getRelativeHeight(6.0))
                            .padding(.leading, getRelativeWidth(33.0))
                            Spacer()
                            VStack {
                                Text(StringConstants.kLbl6)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(7.0))
                                Text(StringConstants.kLblRewards)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(38.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .frame(width: getRelativeWidth(38.0), height: getRelativeHeight(37.0),
                                   alignment: .top)
                            .padding(.vertical, getRelativeHeight(6.0))
                            Spacer()
                            VStack {
                                Text(StringConstants.kLbl7)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(16.0))
                                Text(StringConstants.kLblNotifications)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(56.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .onTapGesture {
                                searchBarViewModel.nextScreen = "NotificationView"
                            }
                            .frame(width: getRelativeWidth(56.0), height: getRelativeHeight(37.0),
                                   alignment: .top)
                            .padding(.vertical, getRelativeHeight(6.0))
                            Spacer()
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLbl8)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(2.0))
                                Text(StringConstants.kLblProfile)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(28.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .onTapGesture {
                                searchBarViewModel.nextScreen = "ProfileView"
                            }
                            .frame(width: getRelativeWidth(28.0), height: getRelativeHeight(37.0),
                                   alignment: .top)
                            .padding(.vertical, getRelativeHeight(6.0))
                            .padding(.trailing, getRelativeWidth(32.0))
                        }
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(56.0),
                               alignment: .leading)
                        .background(ColorConstants.WhiteA700)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(56.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(64.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: ResultView(),
                                   tag: "ResultView",
                                   selection: $searchBarViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: HomeView(),
                                   tag: "HomeView",
                                   selection: $searchBarViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: NotificationView(),
                                   tag: "NotificationView",
                                   selection: $searchBarViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: ProfileView(),
                                   tag: "ProfileView",
                                   selection: $searchBarViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct SearchBarView_Previews: PreviewProvider {
    static var previews: some View {
        SearchBarView()
    }
}
