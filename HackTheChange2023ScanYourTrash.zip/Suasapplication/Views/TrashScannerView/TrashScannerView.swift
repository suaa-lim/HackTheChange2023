import SwiftUI

struct TrashScannerView: View {
    @StateObject var trashScannerViewModel = TrashScannerViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack {
                                HStack {
                                    Image("img_wifi")
                                        .resizable()
                                        .frame(width: getRelativeWidth(18.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(256.0))
                                    Image("img_cellular")
                                        .resizable()
                                        .frame(width: getRelativeWidth(14.0),
                                               height: getRelativeWidth(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                    Image("img_battery")
                                        .resizable()
                                        .frame(width: getRelativeWidth(9.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(9.0))
                                    Image("img_time")
                                        .resizable()
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(10.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(6.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                }
                                .onTapGesture {
                                    trashScannerViewModel.nextScreen = "HomeView"
                                }
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .background(ColorConstants.Green200)
                                HStack {
                                    Image("img_arrowleft_black_900")
                                        .resizable()
                                        .frame(width: getRelativeWidth(10.0),
                                               height: getRelativeHeight(18.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                    Text(StringConstants.kLblTrashScanner2)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(20.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(129.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(15.0))
                                }
                                .frame(width: getRelativeWidth(154.0),
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(11.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                            }
                        }
                        .frame(width: UIScreen.main.bounds.width - 20,
                               height: getRelativeHeight(72.0), alignment: .leading)
                        .background(ColorConstants.Green200)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                        Text(StringConstants.kMsgTakeUploadAP)
                            .font(FontScheme.kRobotoMedium(size: getRelativeHeight(18.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(263.0), height: getRelativeHeight(22.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(29.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(123.0),
                           alignment: .leading)
                    VStack {
                        ZStack(alignment: .center) {
                            Text(StringConstants.kMsgTakeAPhotoOf)
                                .font(FontScheme.kRobotoMedium(size: getRelativeHeight(16.0)))
                                .fontWeight(.medium)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(185.0),
                                       height: getRelativeHeight(19.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(116.04))
                                .padding(.bottom, getRelativeHeight(113.96))
                                .padding(.horizontal, getRelativeWidth(77.81))
                            Image("img_rectangle")
                                .resizable()
                                .frame(width: getRelativeWidth(240.0),
                                       height: getRelativeWidth(240.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .padding(.top, getRelativeHeight(5.0))
                                .padding(.bottom, getRelativeHeight(4.0))
                                .padding(.horizontal, getRelativeWidth(50.0))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(341.0), height: getRelativeHeight(249.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(ColorConstants.Black9000c))
                        .padding(.leading, getRelativeWidth(12.0))
                        .padding(.trailing, getRelativeWidth(7.0))
                        HStack {
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblTakePhoto)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(16.0)))
                                        .fontWeight(.medium)
                                        .padding(.horizontal, getRelativeWidth(30.0))
                                        .padding(.vertical, getRelativeHeight(11.0))
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(164.0),
                                               height: getRelativeHeight(42.0), alignment: .center)
                                        .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                                bottomLeft: 8.0, bottomRight: 8.0)
                                                .stroke(ColorConstants.Black900,
                                                        lineWidth: 1))
                                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                                   bottomLeft: 8.0,
                                                                   bottomRight: 8.0)
                                                .fill(ColorConstants.Green200))
                                }
                            })
                            .frame(width: getRelativeWidth(164.0), height: getRelativeHeight(42.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                    bottomRight: 8.0)
                                    .stroke(ColorConstants.Black900,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                       bottomRight: 8.0)
                                    .fill(ColorConstants.Green200))
                            Spacer()
                            Button(action: {}, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblUploadPhoto)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(16.0)))
                                        .fontWeight(.medium)
                                        .padding(.horizontal, getRelativeWidth(30.0))
                                        .padding(.vertical, getRelativeHeight(11.0))
                                        .foregroundColor(ColorConstants.WhiteA700)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(164.0),
                                               height: getRelativeHeight(42.0), alignment: .center)
                                        .background(RoundedCorners(topLeft: 8.0, topRight: 8.0,
                                                                   bottomLeft: 8.0,
                                                                   bottomRight: 8.0)
                                                .fill(ColorConstants.Black900))
                                }
                            })
                            .frame(width: getRelativeWidth(164.0), height: getRelativeHeight(42.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 8.0, topRight: 8.0, bottomLeft: 8.0,
                                                       bottomRight: 8.0)
                                    .fill(ColorConstants.Black900))
                        }
                        .frame(width: getRelativeWidth(336.0), height: getRelativeHeight(42.0),
                               alignment: .center)
                        .padding(.top, getRelativeHeight(12.0))
                        .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(303.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(12.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgSelectTrashCa)
                            .font(FontScheme.kRobotoMedium(size: getRelativeHeight(14.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(138.0), height: getRelativeHeight(17.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(17.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(14.0))
                    VStack {
                        ScrollView(.horizontal, showsIndicators: false) {
                            HStack {
                                Text(StringConstants.kLblPlastic2)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(10.0))
                                    .padding(.vertical, getRelativeHeight(9.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(64.0),
                                           height: getRelativeHeight(36.0), alignment: .center)
                                    .background(ColorConstants.Black9000c)
                                Text(StringConstants.kLblGlass)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(14.0))
                                    .padding(.vertical, getRelativeHeight(9.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(64.0),
                                           height: getRelativeHeight(36.0), alignment: .center)
                                    .background(ColorConstants.Black9000c)
                                    .padding(.leading, getRelativeWidth(8.0))
                                Text(StringConstants.kLblPaper)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(13.0))
                                    .padding(.bottom, getRelativeHeight(8.0))
                                    .padding(.top, getRelativeHeight(10.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(64.0),
                                           height: getRelativeHeight(36.0), alignment: .center)
                                    .background(ColorConstants.Black9000c)
                                    .padding(.leading, getRelativeWidth(8.0))
                                Text(StringConstants.kLblMetal2)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(14.0))
                                    .padding(.vertical, getRelativeHeight(9.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(64.0),
                                           height: getRelativeHeight(36.0), alignment: .center)
                                    .background(ColorConstants.Black9000c)
                                    .padding(.leading, getRelativeWidth(8.0))
                                Text(StringConstants.kLblOrganic)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(8.0))
                                    .padding(.bottom, getRelativeHeight(8.0))
                                    .padding(.top, getRelativeHeight(10.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(65.0),
                                           height: getRelativeHeight(36.0), alignment: .center)
                                    .background(ColorConstants.Black9000c)
                                    .padding(.leading, getRelativeWidth(8.0))
                                Text(StringConstants.kLblElectronic)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(8.0))
                                    .padding(.vertical, getRelativeHeight(8.0))
                                    .padding(.all, getRelativeWidth(8.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(78.0),
                                           height: getRelativeHeight(36.0), alignment: .center)
                                    .background(ColorConstants.Black9000c)
                                    .padding(.leading, getRelativeWidth(8.0))
                                Text(StringConstants.kLblHazardous)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                                    .fontWeight(.regular)
                                    .padding(.horizontal, getRelativeWidth(8.0))
                                    .padding(.vertical, getRelativeHeight(8.0))
                                    .padding(.all, getRelativeWidth(8.0))
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(84.0),
                                           height: getRelativeHeight(36.0), alignment: .center)
                                    .background(ColorConstants.Black9000c)
                                    .padding(.leading, getRelativeWidth(8.0))
                            }
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(36.0), alignment: .trailing)
                        }
                        .padding(.leading, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(36.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(4.0))
                    VStack(alignment: .leading, spacing: 0) {
                        ZStack(alignment: .bottomLeading) {
                            ZStack(alignment: .center) {
                                FSPagerViewSUI($trashScannerViewModel
                                    .slidercreatefromfraCurrentPage,
                                    trashScannerViewModel.sliderData) { item in
                                        VStack(alignment: .leading, spacing: 0) {
                                            ZStack(alignment: .center) {
                                                ZStack {}
                                                    .hideNavigationBar()
                                                    .frame(width: getRelativeWidth(336.0),
                                                           height: getRelativeHeight(134.0),
                                                           alignment: .topLeading)
                                                    .background(RoundedCorners(topLeft: 6.0,
                                                                               topRight: 6.0,
                                                                               bottomLeft: 6.0,
                                                                               bottomRight: 6.0)
                                                            .fill(ColorConstants.Black9000c))
                                                Text(StringConstants.kMsgDonTForgetTo)
                                                    .font(FontScheme
                                                        .kRobotoMedium(size: getRelativeHeight(16.0)))
                                                    .fontWeight(.medium)
                                                    .foregroundColor(ColorConstants.Black900)
                                                    .minimumScaleFactor(0.5)
                                                    .multilineTextAlignment(.center)
                                                    .frame(width: getRelativeWidth(299.0),
                                                           height: getRelativeHeight(45.0),
                                                           alignment: .center)
                                                    .padding(.bottom, getRelativeHeight(43.0))
                                                    .padding(.horizontal, getRelativeWidth(18.42))
                                            }
                                            .hideNavigationBar()
                                            .frame(width: getRelativeWidth(336.0),
                                                   height: getRelativeHeight(88.0),
                                                   alignment: .leading)
                                            Image("img_rectangle_114x336")
                                                .resizable()
                                                .frame(width: getRelativeWidth(336.0),
                                                       height: getRelativeHeight(114.0),
                                                       alignment: .center)
                                                .scaledToFit()
                                                .clipped()
                                                .padding(.top, getRelativeHeight(4.0))
                                        }
                                        .frame(width: getRelativeWidth(336.0),
                                               height: getRelativeHeight(206.0))
                                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                                   bottomLeft: 6.0,
                                                                   bottomRight: 6.0)
                                                .fill(ColorConstants.Black9000c))
                                    }
                                PageIndicator(numPages: trashScannerViewModel.sliderData.count,
                                              currentPage: $trashScannerViewModel
                                                  .slidercreatefromfraCurrentPage,
                                              selectedColor: ColorConstants.WhiteA700,
                                              unSelectedColor: ColorConstants.Black9004c,
                                              spacing: 4.0)
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(336.0), height: getRelativeHeight(206.0),
                                   alignment: .center)
                            .padding(.horizontal, getRelativeWidth(12.0))
                            HStack {
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(StringConstants.kLbl5)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(1.0))
                                    Text(StringConstants.kLblHome)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(27.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .onTapGesture {
                                    trashScannerViewModel.nextScreen = "HomeView"
                                }
                                .frame(width: getRelativeWidth(27.0),
                                       height: getRelativeHeight(38.0), alignment: .top)
                                .padding(.leading, getRelativeWidth(31.0))
                                VStack {
                                    Text(StringConstants.kLbl6)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(7.0))
                                    Text(StringConstants.kLblRewards)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(38.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .frame(width: getRelativeWidth(38.0),
                                       height: getRelativeHeight(37.0), alignment: .top)
                                .padding(.leading, getRelativeWidth(57.0))
                                VStack {
                                    Text(StringConstants.kLbl7)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(16.0))
                                    Text(StringConstants.kLblNotifications)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(56.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .onTapGesture {
                                    trashScannerViewModel.nextScreen = "NotificationView"
                                }
                                .frame(width: getRelativeWidth(56.0),
                                       height: getRelativeHeight(37.0), alignment: .top)
                                .padding(.leading, getRelativeWidth(42.0))
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(StringConstants.kLbl8)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(2.0))
                                    Text(StringConstants.kLblProfile)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(28.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .onTapGesture {
                                    trashScannerViewModel.nextScreen = "ProfileView"
                                }
                                .frame(width: getRelativeWidth(28.0),
                                       height: getRelativeHeight(37.0), alignment: .top)
                                .padding(.leading, getRelativeWidth(47.0))
                                .padding(.trailing, getRelativeWidth(30.0))
                            }
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(56.0),
                                   alignment: .bottomLeading)
                            .background(ColorConstants.WhiteA700)
                            .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                            .padding(.top, getRelativeHeight(100.96))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(206.0),
                               alignment: .leading)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(206.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(64.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: NotificationView(),
                                   tag: "NotificationView",
                                   selection: $trashScannerViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: ProfileView(),
                                   tag: "ProfileView",
                                   selection: $trashScannerViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: TrashScannerResultView(),
                                   tag: "TrashScannerResultView",
                                   selection: $trashScannerViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: HomeView(),
                                   tag: "HomeView",
                                   selection: $trashScannerViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct TrashScannerView_Previews: PreviewProvider {
    static var previews: some View {
        TrashScannerView()
    }
}
