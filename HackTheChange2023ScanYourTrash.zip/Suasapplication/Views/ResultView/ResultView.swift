import SwiftUI

struct ResultView: View {
    @StateObject var resultViewModel = ResultViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        VStack {
                            HStack {
                                Image("img_wifi")
                                    .resizable()
                                    .frame(width: getRelativeWidth(18.0),
                                           height: getRelativeHeight(14.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(5.0))
                                    .padding(.leading, getRelativeWidth(271.0))
                                Image("img_cellular")
                                    .resizable()
                                    .frame(width: getRelativeWidth(14.0),
                                           height: getRelativeWidth(14.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(5.0))
                                Image("img_battery")
                                    .resizable()
                                    .frame(width: getRelativeWidth(9.0),
                                           height: getRelativeHeight(14.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(5.0))
                                    .padding(.leading, getRelativeWidth(9.0))
                                Image("img_time")
                                    .resizable()
                                    .frame(width: getRelativeWidth(33.0),
                                           height: getRelativeHeight(10.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(6.0))
                                    .padding(.horizontal, getRelativeWidth(8.0))
                            }
                            .onTapGesture {
                                resultViewModel.nextScreen = "HomeView"
                            }
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(24.0), alignment: .leading)
                            .background(ColorConstants.Green200)
                            HStack {
                                Image("img_arrowleft_black_900")
                                    .resizable()
                                    .frame(width: getRelativeWidth(10.0),
                                           height: getRelativeHeight(18.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .onTapGesture {
                                        self.presentationMode.wrappedValue.dismiss()
                                    }
                                Text(StringConstants.kLblSearchBar)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(20.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(98.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.leading, getRelativeWidth(15.0))
                            }
                            .frame(width: getRelativeWidth(123.0), height: getRelativeHeight(24.0),
                                   alignment: .leading)
                            .padding(.top, getRelativeHeight(11.0))
                            .padding(.bottom, getRelativeHeight(12.0))
                            .padding(.horizontal, getRelativeWidth(15.0))
                        }
                        .background(ColorConstants.Green200)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width - 20, height: getRelativeHeight(76.0),
                           alignment: .leading)
                    .background(ColorConstants.Green200)
                    .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    ZStack(alignment: .leading) {
                        ZStack {}
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(303.0), height: getRelativeHeight(205.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                       bottomLeft: 10.0, bottomRight: 10.0)
                                    .fill(ColorConstants.Teal50))
                            .padding(.bottom, getRelativeHeight(379.0))
                            .padding(.horizontal, getRelativeWidth(36.0))
                        ZStack(alignment: .bottomLeading) {
                            Image("img_darkblue_bluegray_500")
                                .resizable()
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(673.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                            VStack {
                                Text(StringConstants.kMsgTheItemYouSe)
                                    .font(FontScheme
                                        .kRedHatTextMedium(size: getRelativeHeight(24.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(232.0),
                                           height: getRelativeHeight(70.0), alignment: .center)
                                    .padding(.horizontal, getRelativeWidth(36.0))
                                Button(action: {}, label: {
                                    HStack(spacing: 0) {
                                        Text(StringConstants.kLblPaper2)
                                            .font(FontScheme
                                                .kRedHatTextRomanBold(size: getRelativeHeight(40.0)))
                                            .fontWeight(.bold)
                                            .padding(.horizontal, getRelativeWidth(30.0))
                                            .padding(.vertical, getRelativeHeight(11.0))
                                            .foregroundColor(ColorConstants.Bluegray700)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(257.0),
                                                   height: getRelativeHeight(76.0),
                                                   alignment: .topLeading)
                                            .background(ColorConstants.Green200)
                                            .padding(.top, getRelativeHeight(4.0))
                                            .padding(.horizontal, getRelativeWidth(36.0))
                                    }
                                })
                                .frame(width: getRelativeWidth(257.0),
                                       height: getRelativeHeight(76.0), alignment: .topLeading)
                                .background(ColorConstants.Green200)
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.horizontal, getRelativeWidth(36.0))
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(StringConstants.kLblBenefits)
                                        .font(FontScheme
                                            .kRedHatTextMedium(size: getRelativeHeight(24.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.OrangeA200)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(101.0),
                                               height: getRelativeHeight(32.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(30.0))
                                        .padding(.horizontal, getRelativeWidth(27.0))
                                    Text(StringConstants.kMsgRecyclingOneT)
                                        .font(FontScheme
                                            .kRedHatTextRomanBold(size: getRelativeHeight(20.0)))
                                        .fontWeight(.bold)
                                        .foregroundColor(ColorConstants.Orange200)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(203.0),
                                               height: getRelativeHeight(65.0),
                                               alignment: .topLeading)
                                        .padding(.vertical, getRelativeHeight(6.0))
                                        .padding(.horizontal, getRelativeWidth(27.0))
                                }
                                .frame(width: getRelativeWidth(303.0),
                                       height: getRelativeHeight(163.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                           bottomLeft: 10.0, bottomRight: 10.0)
                                        .fill(ColorConstants.Orange51))
                                .padding(.top, getRelativeHeight(32.0))
                                .padding(.horizontal, getRelativeWidth(36.0))
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(StringConstants.kLblPoints)
                                        .font(FontScheme
                                            .kRedHatTextMedium(size: getRelativeHeight(24.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Yellow800)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(77.0),
                                               height: getRelativeHeight(32.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(32.0))
                                        .padding(.horizontal, getRelativeWidth(27.0))
                                    Text(StringConstants.kMsgYouHaveEarned)
                                        .font(FontScheme
                                            .kRedHatTextRomanBold(size: getRelativeHeight(20.0)))
                                        .fontWeight(.bold)
                                        .foregroundColor(ColorConstants.Orange200)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(178.0),
                                               height: getRelativeHeight(64.0),
                                               alignment: .topLeading)
                                        .padding(.vertical, getRelativeHeight(4.0))
                                        .padding(.horizontal, getRelativeWidth(27.0))
                                }
                                .frame(width: getRelativeWidth(303.0),
                                       height: getRelativeHeight(163.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 10.0, topRight: 10.0,
                                                           bottomLeft: 10.0, bottomRight: 10.0)
                                        .fill(ColorConstants.Orange51))
                                .padding(.top, getRelativeHeight(14.0))
                                .padding(.horizontal, getRelativeWidth(36.0))
                                HStack {
                                    VStack(alignment: .leading, spacing: 0) {
                                        Text(StringConstants.kLbl5)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(20.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(22.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.horizontal, getRelativeWidth(1.0))
                                        Text(StringConstants.kLblHome)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(10.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(27.0),
                                                   height: getRelativeHeight(12.0),
                                                   alignment: .topLeading)
                                    }
                                    .onTapGesture {
                                        resultViewModel.nextScreen = "HomeView"
                                    }
                                    .frame(width: getRelativeWidth(27.0),
                                           height: getRelativeHeight(38.0), alignment: .top)
                                    .padding(.vertical, getRelativeHeight(6.0))
                                    .padding(.leading, getRelativeWidth(33.0))
                                    Spacer()
                                    VStack {
                                        Text(StringConstants.kLbl6)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(20.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(22.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.horizontal, getRelativeWidth(7.0))
                                        Text(StringConstants.kLblRewards)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(10.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(38.0),
                                                   height: getRelativeHeight(12.0),
                                                   alignment: .topLeading)
                                    }
                                    .frame(width: getRelativeWidth(38.0),
                                           height: getRelativeHeight(37.0), alignment: .top)
                                    .padding(.vertical, getRelativeHeight(6.0))
                                    Spacer()
                                    VStack {
                                        Text(StringConstants.kLbl7)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(20.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(22.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.horizontal, getRelativeWidth(16.0))
                                        Text(StringConstants.kLblNotifications)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(10.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(56.0),
                                                   height: getRelativeHeight(12.0),
                                                   alignment: .topLeading)
                                    }
                                    .onTapGesture {
                                        resultViewModel.nextScreen = "NotificationView"
                                    }
                                    .frame(width: getRelativeWidth(56.0),
                                           height: getRelativeHeight(37.0), alignment: .top)
                                    .padding(.vertical, getRelativeHeight(6.0))
                                    Spacer()
                                    VStack(alignment: .leading, spacing: 0) {
                                        Text(StringConstants.kLbl8)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(20.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(22.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .padding(.horizontal, getRelativeWidth(2.0))
                                        Text(StringConstants.kLblProfile)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(10.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(28.0),
                                                   height: getRelativeHeight(12.0),
                                                   alignment: .topLeading)
                                    }
                                    .onTapGesture {
                                        resultViewModel.nextScreen = "ProfileView"
                                    }
                                    .frame(width: getRelativeWidth(28.0),
                                           height: getRelativeHeight(37.0), alignment: .top)
                                    .padding(.vertical, getRelativeHeight(6.0))
                                    .padding(.trailing, getRelativeWidth(32.0))
                                }
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(56.0), alignment: .leading)
                                .background(ColorConstants.WhiteA700)
                                .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                                .padding(.top, getRelativeHeight(38.0))
                            }
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(617.0),
                                   alignment: .bottomLeading)
                            .padding(.top, getRelativeHeight(55.91))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(673.0),
                               alignment: .leading)
                    }
                    .hideNavigationBar()
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(673.0),
                           alignment: .leading)
                    .padding(.vertical, getRelativeHeight(62.0))
                }
                .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height,
                       alignment: .topLeading)
                .background(ColorConstants.Orange50)
                Group {
                    NavigationLink(destination: ProfileView(),
                                   tag: "ProfileView",
                                   selection: $resultViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: HomeView(),
                                   tag: "HomeView",
                                   selection: $resultViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: NotificationView(),
                                   tag: "NotificationView",
                                   selection: $resultViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct ResultView_Previews: PreviewProvider {
    static var previews: some View {
        ResultView()
    }
}
