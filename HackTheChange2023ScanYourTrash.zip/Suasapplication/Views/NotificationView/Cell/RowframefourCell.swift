import SwiftUI

struct RowframefourCell: View {
    var body: some View {
        HStack {
            Button(action: {}, label: {
                Image("img_frame")
            })
            .frame(width: getRelativeWidth(30.0), height: getRelativeWidth(32.0),
                   alignment: .center)
            .background(RoundedCorners(topLeft: 16.0, topRight: 16.0, bottomLeft: 16.0,
                                       bottomRight: 16.0)
                    .fill(ColorConstants.Black9000c))
            VStack(alignment: .leading, spacing: 0) {
                Text(StringConstants.kLblRewards2)
                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                    .fontWeight(.regular)
                    .foregroundColor(ColorConstants.Black900)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: getRelativeWidth(55.0), height: getRelativeHeight(17.0),
                           alignment: .leading)
                    .padding(.trailing)
                Text(StringConstants.kMsgYouHaveEarned)
                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                    .fontWeight(.regular)
                    .foregroundColor(ColorConstants.Black9007f)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: getRelativeWidth(135.0), height: getRelativeHeight(15.0),
                           alignment: .leading)
            }
            .frame(width: getRelativeWidth(135.0), height: getRelativeHeight(34.0),
                   alignment: .leading)
            .padding(.leading, getRelativeWidth(8.0))
        }
        .frame(width: getRelativeWidth(175.0), alignment: .leading)
        .hideNavigationBar()
    }
}

/* struct RowframefourCell_Previews: PreviewProvider {

 static var previews: some View {
 			RowframefourCell()
 }
 } */
