import SwiftUI

struct Card1Cell: View {
    var body: some View {
        VStack(alignment: .leading, spacing: 0) {
            HStack {
                ZStack {}
                    .hideNavigationBar()
                    .frame(width: getRelativeWidth(22.0), height: getRelativeWidth(24.0),
                           alignment: .leading)
                    .background(RoundedCorners(topLeft: 12.0, topRight: 12.0, bottomLeft: 12.0,
                                               bottomRight: 12.0)
                            .fill(ColorConstants.Black90019))
                Text(StringConstants.kLblJaneSmith)
                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(12.0)))
                    .fontWeight(.medium)
                    .foregroundColor(ColorConstants.Black900)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: getRelativeWidth(58.0), height: getRelativeHeight(15.0),
                           alignment: .leading)
                    .padding(.vertical, getRelativeHeight(4.0))
                    .padding(.leading, getRelativeWidth(8.0))
                Image("img_vector")
                    .resizable()
                    .frame(width: getRelativeWidth(56.0), height: getRelativeHeight(9.0),
                           alignment: .leading)
                    .scaledToFit()
                    .padding(.vertical, getRelativeHeight(7.0))
                    .padding(.leading, getRelativeWidth(44.0))
                Spacer()
            }
            .frame(width: getRelativeWidth(194.0), height: getRelativeHeight(24.0),
                   alignment: .leading)
            .padding(.top, getRelativeHeight(12.0))
            .padding(.horizontal, getRelativeWidth(12.0))
            Text(StringConstants.kMsgTheWasteManag)
                .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                .fontWeight(.regular)
                .foregroundColor(ColorConstants.Black900)
                .minimumScaleFactor(0.5)
                .multilineTextAlignment(.leading)
                .frame(width: getRelativeWidth(182.0), height: getRelativeHeight(60.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(9.0))
                .padding(.bottom, getRelativeHeight(10.0))
                .padding(.horizontal, getRelativeWidth(12.0))
        }
        .frame(width: getRelativeWidth(218.0), alignment: .leading)
        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0, bottomRight: 6.0)
            .fill(ColorConstants.Black9000c))
        .hideNavigationBar()
    }
}

/* struct Card1Cell_Previews: PreviewProvider {

 static var previews: some View {
 			Card1Cell()
 }
 } */
