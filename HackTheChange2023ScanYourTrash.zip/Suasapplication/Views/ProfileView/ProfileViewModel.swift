import Foundation
import SwiftUI

class ProfileViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
