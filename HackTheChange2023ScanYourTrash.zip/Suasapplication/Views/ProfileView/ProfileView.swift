import SwiftUI

struct ProfileView: View {
    @StateObject var profileViewModel = ProfileViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack(alignment: .leading, spacing: 0) {
                    HStack {
                        VStack {
                            HStack {
                                Image("img_wifi")
                                    .resizable()
                                    .frame(width: getRelativeWidth(18.0),
                                           height: getRelativeHeight(14.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(5.0))
                                    .padding(.leading, getRelativeWidth(256.0))
                                Image("img_cellular")
                                    .resizable()
                                    .frame(width: getRelativeWidth(14.0),
                                           height: getRelativeWidth(14.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(5.0))
                                Image("img_battery")
                                    .resizable()
                                    .frame(width: getRelativeWidth(9.0),
                                           height: getRelativeHeight(14.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(5.0))
                                    .padding(.leading, getRelativeWidth(9.0))
                                Image("img_time")
                                    .resizable()
                                    .frame(width: getRelativeWidth(33.0),
                                           height: getRelativeHeight(10.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.vertical, getRelativeHeight(6.0))
                                    .padding(.horizontal, getRelativeWidth(8.0))
                            }
                            .onTapGesture {
                                profileViewModel.nextScreen = "HomeView"
                            }
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(24.0), alignment: .leading)
                            .background(ColorConstants.Green200)
                            HStack {
                                Image("img_arrowleft_black_900")
                                    .resizable()
                                    .frame(width: getRelativeWidth(10.0),
                                           height: getRelativeHeight(18.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .onTapGesture {
                                        self.presentationMode.wrappedValue.dismiss()
                                    }
                                Text(StringConstants.kLblProfile)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(20.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(59.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.leading, getRelativeWidth(15.0))
                            }
                            .frame(width: getRelativeWidth(84.0), height: getRelativeHeight(24.0),
                                   alignment: .leading)
                            .padding(.top, getRelativeHeight(11.0))
                            .padding(.horizontal, getRelativeWidth(15.0))
                        }
                    }
                    .frame(width: UIScreen.main.bounds.width - 20, height: getRelativeHeight(72.0),
                           alignment: .leading)
                    .background(ColorConstants.Green200)
                    .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    ScrollView(.vertical, showsIndicators: false) {
                        VStack(alignment: .leading, spacing: 0) {
                            HStack {
                                ZStack {}
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(40.0),
                                           height: getRelativeWidth(40.0), alignment: .center)
                                    .background(RoundedCorners(topLeft: 20.0, topRight: 20.0,
                                                               bottomLeft: 20.0, bottomRight: 20.0)
                                            .fill(ColorConstants.Black90019))
                                Text(StringConstants.kLblCodeRunner)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(16.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(92.0),
                                           height: getRelativeHeight(19.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(9.0))
                                    .padding(.bottom, getRelativeHeight(11.0))
                                    .padding(.leading, getRelativeWidth(12.0))
                            }
                            .frame(width: getRelativeWidth(144.0), height: getRelativeHeight(40.0),
                                   alignment: .leading)
                            .padding(.horizontal, getRelativeWidth(12.0))
                            Text(StringConstants.kLblAbout)
                                .font(FontScheme.kRobotoMedium(size: getRelativeHeight(18.0)))
                                .fontWeight(.medium)
                                .foregroundColor(ColorConstants.Black900)
                                .minimumScaleFactor(0.5)
                                .multilineTextAlignment(.leading)
                                .frame(width: getRelativeWidth(48.0),
                                       height: getRelativeHeight(22.0), alignment: .topLeading)
                                .padding(.top, getRelativeHeight(28.0))
                                .padding(.horizontal, getRelativeWidth(12.0))
                            VStack(spacing: 0) {
                                ScrollView(.vertical, showsIndicators: false) {
                                    LazyVStack {
                                        ForEach(0 ... 2, id: \.self) { index in
                                            Rowtitle1Cell()
                                        }
                                    }
                                }
                            }
                            .frame(width: getRelativeWidth(329.0), alignment: .center)
                            .padding(.top, getRelativeHeight(21.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                            Divider()
                                .frame(width: getRelativeWidth(336.0),
                                       height: getRelativeHeight(1.0), alignment: .center)
                                .background(ColorConstants.Black90019)
                                .padding(.top, getRelativeHeight(8.0))
                                .padding(.horizontal, getRelativeWidth(12.0))
                            HStack {
                                Text(StringConstants.kLblProducts)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(18.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(73.0),
                                           height: getRelativeHeight(22.0), alignment: .topLeading)
                                Spacer()
                                HStack {
                                    Text(StringConstants.kLblSeeAll)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(12.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(37.0),
                                               height: getRelativeHeight(15.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(8.0))
                                    Image("img_arrowright")
                                        .resizable()
                                        .frame(width: getRelativeWidth(5.0),
                                               height: getRelativeHeight(10.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.horizontal, getRelativeWidth(6.0))
                                }
                                .frame(width: getRelativeWidth(63.0),
                                       height: getRelativeHeight(22.0), alignment: .center)
                                .overlay(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                        bottomLeft: 4.0,
                                                        bottomRight: 4.0)
                                        .stroke(ColorConstants.Black900,
                                                lineWidth: 1))
                                .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                           bottomLeft: 4.0, bottomRight: 4.0)
                                        .fill(Color.clear.opacity(0.7)))
                            }
                            .frame(width: getRelativeWidth(336.0), height: getRelativeHeight(22.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(27.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                            HStack {
                                VStack {
                                    ZStack(alignment: .center) {
                                        ZStack(alignment: .bottomLeading) {
                                            Divider()
                                                .frame(width: getRelativeWidth(1.0),
                                                       height: getRelativeHeight(105.0),
                                                       alignment: .leading)
                                                .background(ColorConstants.Black9000c)
                                                .padding(.trailing, getRelativeWidth(74.0))
                                            Text(StringConstants.kLblRecyclingBin)
                                                .font(FontScheme
                                                    .kRobotoRegular(size: getRelativeHeight(12.0)))
                                                .fontWeight(.regular)
                                                .foregroundColor(ColorConstants.Black900)
                                                .minimumScaleFactor(0.5)
                                                .multilineTextAlignment(.center)
                                                .frame(width: getRelativeWidth(13.0),
                                                       height: getRelativeHeight(46.0),
                                                       alignment: .center)
                                                .padding(.top, getRelativeHeight(58.47))
                                                .padding(.trailing, getRelativeWidth(62.0))
                                            VStack {
                                                Text(StringConstants.kLblEcoFriendly)
                                                    .font(FontScheme
                                                        .kRobotoMedium(size: getRelativeHeight(12.0)))
                                                    .fontWeight(.medium)
                                                    .foregroundColor(ColorConstants.Black900)
                                                    .minimumScaleFactor(0.5)
                                                    .multilineTextAlignment(.leading)
                                                    .frame(width: getRelativeWidth(67.0),
                                                           height: getRelativeHeight(15.0),
                                                           alignment: .topLeading)
                                                    .padding(.top, getRelativeHeight(5.0))
                                                    .padding(.horizontal, getRelativeWidth(4.0))
                                            }
                                            .frame(width: getRelativeWidth(75.0),
                                                   height: getRelativeHeight(24.0),
                                                   alignment: .topLeading)
                                            .background(RoundedCorners(topLeft: 6.0,
                                                                       bottomRight: 6.0)
                                                    .fill(ColorConstants
                                                        .Black9000c))
                                            .padding(.bottom, getRelativeHeight(81.0))
                                        }
                                        .hideNavigationBar()
                                        .frame(width: getRelativeWidth(75.0),
                                               height: getRelativeHeight(105.0),
                                               alignment: .topLeading)
                                        .background(ColorConstants.Black9000c)
                                        .padding(.bottom, getRelativeHeight(59.0))
                                        .padding(.trailing, getRelativeWidth(89.0))
                                        Image("img_image16")
                                            .resizable()
                                            .frame(width: getRelativeWidth(163.0),
                                                   height: getRelativeHeight(164.0),
                                                   alignment: .center)
                                            .scaledToFit()
                                            .clipped()
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(164.0),
                                           height: getRelativeWidth(164.0), alignment: .leading)
                                    Text(StringConstants.kLblRecyclingBin)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(12.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(71.0),
                                               height: getRelativeHeight(15.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(9.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                    Text(StringConstants.kLbl100KgRecycled)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(16.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(112.0),
                                               height: getRelativeHeight(19.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(6.0))
                                        .padding(.bottom, getRelativeHeight(9.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                }
                                .frame(width: getRelativeWidth(164.0),
                                       height: getRelativeHeight(224.0), alignment: .center)
                                .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                        bottomLeft: 6.0,
                                                        bottomRight: 6.0)
                                        .stroke(ColorConstants.Black90019,
                                                lineWidth: 1))
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0)
                                        .fill(Color.clear.opacity(0.7)))
                                Spacer()
                                VStack {
                                    VStack {
                                        ZStack(alignment: .leading) {
                                            Text(StringConstants.kLblCompostBin)
                                                .font(FontScheme
                                                    .kRobotoRegular(size: getRelativeHeight(12.0)))
                                                .fontWeight(.regular)
                                                .foregroundColor(ColorConstants.Black900)
                                                .minimumScaleFactor(0.5)
                                                .multilineTextAlignment(.leading)
                                                .frame(width: getRelativeWidth(68.0),
                                                       height: getRelativeHeight(15.0),
                                                       alignment: .topLeading)
                                                .padding(.top, getRelativeHeight(75.4))
                                                .padding(.bottom, getRelativeHeight(73.6))
                                                .padding(.horizontal, getRelativeWidth(47.48))
                                            Image("img_image17")
                                                .resizable()
                                                .frame(width: getRelativeWidth(164.0),
                                                       height: getRelativeWidth(164.0),
                                                       alignment: .center)
                                                .scaledToFit()
                                                .clipped()
                                        }
                                        .hideNavigationBar()
                                        .frame(width: getRelativeWidth(164.0),
                                               height: getRelativeWidth(164.0), alignment: .leading)
                                        .background(ColorConstants.Black9000c)
                                    }
                                    .frame(width: getRelativeWidth(164.0),
                                           height: getRelativeWidth(164.0), alignment: .leading)
                                    .background(ColorConstants.Black9000c)
                                    Text(StringConstants.kLblCompostBin)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(12.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(68.0),
                                               height: getRelativeHeight(15.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(9.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                    Text(StringConstants.kLbl50KgComposted)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(16.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(124.0),
                                               height: getRelativeHeight(19.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(6.0))
                                        .padding(.bottom, getRelativeHeight(9.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                }
                                .frame(width: getRelativeWidth(164.0),
                                       height: getRelativeHeight(224.0), alignment: .center)
                                .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                        bottomLeft: 6.0,
                                                        bottomRight: 6.0)
                                        .stroke(ColorConstants.Black90019,
                                                lineWidth: 1))
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0)
                                        .fill(Color.clear.opacity(0.7)))
                            }
                            .frame(width: getRelativeWidth(336.0), height: getRelativeHeight(224.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(13.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                            HStack {
                                Text(StringConstants.kLblReviews)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(18.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(67.0),
                                           height: getRelativeHeight(22.0), alignment: .topLeading)
                                Spacer()
                                HStack {
                                    Text(StringConstants.kLblWriteAReview)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(12.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(79.0),
                                               height: getRelativeHeight(15.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(8.0))
                                    Image("img_arrowright")
                                        .resizable()
                                        .frame(width: getRelativeWidth(5.0),
                                               height: getRelativeHeight(10.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.horizontal, getRelativeWidth(6.0))
                                }
                                .frame(width: getRelativeWidth(105.0),
                                       height: getRelativeHeight(22.0), alignment: .center)
                                .overlay(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                        bottomLeft: 4.0,
                                                        bottomRight: 4.0)
                                        .stroke(ColorConstants.Black900,
                                                lineWidth: 1))
                                .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                           bottomLeft: 4.0, bottomRight: 4.0)
                                        .fill(Color.clear.opacity(0.7)))
                            }
                            .frame(width: getRelativeWidth(336.0), height: getRelativeHeight(22.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(28.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                            HStack(spacing: 0) {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    LazyHStack {
                                        ForEach(0 ... 1, id: \.self) { index in
                                            Card1Cell()
                                        }
                                    }
                                }
                            }
                            .frame(width: UIScreen.main.bounds.width, alignment: .trailing)
                            .padding(.top, getRelativeHeight(13.0))
                            HStack {
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(StringConstants.kLbl5)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(1.0))
                                    Text(StringConstants.kLblHome)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(27.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .onTapGesture {
                                    profileViewModel.nextScreen = "HomeView"
                                }
                                .frame(width: getRelativeWidth(27.0),
                                       height: getRelativeHeight(38.0), alignment: .top)
                                .padding(.vertical, getRelativeHeight(6.0))
                                .padding(.leading, getRelativeWidth(31.0))
                                Spacer()
                                VStack {
                                    Text(StringConstants.kLbl6)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(7.0))
                                    Text(StringConstants.kLblRewards)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(38.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .frame(width: getRelativeWidth(38.0),
                                       height: getRelativeHeight(37.0), alignment: .top)
                                .padding(.vertical, getRelativeHeight(6.0))
                                Spacer()
                                VStack {
                                    Text(StringConstants.kLbl7)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(16.0))
                                        .onTapGesture {
                                            profileViewModel.nextScreen = "NotificationView"
                                        }
                                    Text(StringConstants.kLblNotifications)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(56.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .onTapGesture {
                                    profileViewModel.nextScreen = "NotificationView"
                                }
                                .frame(width: getRelativeWidth(56.0),
                                       height: getRelativeHeight(37.0), alignment: .top)
                                .padding(.vertical, getRelativeHeight(6.0))
                                Spacer()
                                VStack(alignment: .leading, spacing: 0) {
                                    Text(StringConstants.kLbl8)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(20.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(22.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.horizontal, getRelativeWidth(2.0))
                                    Text(StringConstants.kLblProfile)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(10.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(28.0),
                                               height: getRelativeHeight(12.0),
                                               alignment: .topLeading)
                                }
                                .frame(width: getRelativeWidth(28.0),
                                       height: getRelativeHeight(37.0), alignment: .top)
                                .padding(.vertical, getRelativeHeight(6.0))
                                .padding(.trailing, getRelativeWidth(30.0))
                            }
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(56.0), alignment: .leading)
                            .background(ColorConstants.WhiteA700)
                            .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                            .padding(.top, getRelativeHeight(12.0))
                        }
                        .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                    }
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: HomeView(),
                                   tag: "HomeView",
                                   selection: $profileViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: NotificationView(),
                                   tag: "NotificationView",
                                   selection: $profileViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct ProfileView_Previews: PreviewProvider {
    static var previews: some View {
        ProfileView()
    }
}
