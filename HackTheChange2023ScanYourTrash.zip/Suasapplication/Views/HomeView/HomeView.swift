import SwiftUI

struct HomeView: View {
    @StateObject var homeViewModel = HomeViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack {
                                HStack {
                                    Image("img_wifi")
                                        .resizable()
                                        .frame(width: getRelativeWidth(18.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(256.0))
                                    Image("img_cellular")
                                        .resizable()
                                        .frame(width: getRelativeWidth(14.0),
                                               height: getRelativeWidth(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                    Image("img_battery")
                                        .resizable()
                                        .frame(width: getRelativeWidth(9.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(9.0))
                                    Image("img_time")
                                        .resizable()
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(10.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(6.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                }
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .background(ColorConstants.Green200)
                                HStack {
                                    Image("img_arrowleft_black_900")
                                        .resizable()
                                        .frame(width: getRelativeWidth(10.0),
                                               height: getRelativeHeight(18.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.bottom, getRelativeHeight(4.0))
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                    Text(StringConstants.kLblHomePage)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(20.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(104.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(15.0))
                                }
                                .frame(width: getRelativeWidth(129.0),
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(13.0))
                                .padding(.horizontal, getRelativeWidth(23.0))
                            }
                        }
                        .frame(width: UIScreen.main.bounds.width - 20,
                               height: getRelativeHeight(72.0), alignment: .leading)
                        .background(ColorConstants.Green200)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(72.0),
                           alignment: .trailing)
                    VStack {
                        HStack {
                            VStack {
                                VStack {
                                    Text(StringConstants.kLbl)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(30.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(36.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(6.0))
                                        .padding(.bottom, getRelativeHeight(5.0))
                                        .padding(.horizontal, getRelativeWidth(7.0))
                                }
                                .onTapGesture {
                                    homeViewModel.nextScreen = "TrashScannerView"
                                }
                                .frame(width: getRelativeWidth(48.0),
                                       height: getRelativeWidth(48.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 24.0, topRight: 24.0,
                                                           bottomLeft: 24.0, bottomRight: 24.0)
                                        .fill(ColorConstants.Black9000c))
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                                Text(StringConstants.kLblTrashScanner)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(37.0),
                                           height: getRelativeHeight(28.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(4.0))
                                    .padding(.horizontal, getRelativeWidth(15.0))
                            }
                            .frame(width: getRelativeWidth(78.0), height: getRelativeHeight(88.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Black90019,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(Color.clear.opacity(0.7)))
                            Spacer()
                            VStack {
                                VStack {
                                    Text(StringConstants.kLbl2)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(30.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(36.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(6.0))
                                        .padding(.bottom, getRelativeHeight(5.0))
                                        .padding(.horizontal, getRelativeWidth(7.0))
                                }
                                .onTapGesture {
                                    homeViewModel.nextScreen = "RecyclingCentersView"
                                }
                                .frame(width: getRelativeWidth(48.0),
                                       height: getRelativeWidth(48.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 24.0, topRight: 24.0,
                                                           bottomLeft: 24.0, bottomRight: 24.0)
                                        .fill(ColorConstants.Black9000c))
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                                Text(StringConstants.kMsgRecyclingCente)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(42.0),
                                           height: getRelativeHeight(28.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(4.0))
                                    .padding(.horizontal, getRelativeWidth(15.0))
                            }
                            .frame(width: getRelativeWidth(78.0), height: getRelativeHeight(88.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Black90019,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(Color.clear.opacity(0.7)))
                            Spacer()
                            VStack {
                                VStack {
                                    Text(StringConstants.kLbl3)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(30.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(36.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(6.0))
                                        .padding(.bottom, getRelativeHeight(5.0))
                                        .padding(.horizontal, getRelativeWidth(7.0))
                                }
                                .onTapGesture {
                                    homeViewModel.nextScreen = "SearchBarView"
                                }
                                .frame(width: getRelativeWidth(48.0),
                                       height: getRelativeWidth(48.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 24.0, topRight: 24.0,
                                                           bottomLeft: 24.0, bottomRight: 24.0)
                                        .fill(ColorConstants.Black9000c))
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.horizontal, getRelativeWidth(14.0))
                                Text(StringConstants.kLblSearchBar)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(49.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(11.0))
                                    .padding(.bottom, getRelativeHeight(12.0))
                                    .padding(.horizontal, getRelativeWidth(14.0))
                            }
                            .frame(width: getRelativeWidth(78.0), height: getRelativeHeight(88.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Black90019,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(Color.clear.opacity(0.7)))
                            Spacer()
                            VStack {
                                VStack {
                                    Text(StringConstants.kLbl4)
                                        .font(FontScheme
                                            .kRobotoRegular(size: getRelativeHeight(30.0)))
                                        .fontWeight(.regular)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(36.0),
                                               alignment: .topLeading)
                                        .padding(.top, getRelativeHeight(6.0))
                                        .padding(.bottom, getRelativeHeight(5.0))
                                        .padding(.horizontal, getRelativeWidth(7.0))
                                }
                                .frame(width: getRelativeWidth(48.0),
                                       height: getRelativeWidth(48.0), alignment: .center)
                                .background(RoundedCorners(topLeft: 24.0, topRight: 24.0,
                                                           bottomLeft: 24.0, bottomRight: 24.0)
                                        .fill(ColorConstants.Black9000c))
                                .padding(.top, getRelativeHeight(4.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                                Text(StringConstants.kLblEducation)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(44.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(11.0))
                                    .padding(.bottom, getRelativeHeight(12.0))
                                    .padding(.horizontal, getRelativeWidth(15.0))
                            }
                            .frame(width: getRelativeWidth(78.0), height: getRelativeHeight(88.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Black90019,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(Color.clear.opacity(0.7)))
                        }
                        .frame(width: getRelativeWidth(336.0), height: getRelativeHeight(88.0),
                               alignment: .center)
                        .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(88.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(12.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgWelcomeToScan)
                            .font(FontScheme.kRobotoMedium(size: getRelativeHeight(18.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(230.0), height: getRelativeHeight(22.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(12.0))
                        Text(StringConstants.kMsgHelpingYouMak)
                            .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black9007f)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(164.0), height: getRelativeHeight(15.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(39.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(28.0))
                    VStack(alignment: .trailing, spacing: 0) {
                        HStack {
                            HStack(spacing: 0) {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    LazyHStack {
                                        ForEach(0 ... 1, id: \.self) { index in
                                            CardCell()
                                        }
                                    }
                                }
                            }
                            .frame(width: getRelativeWidth(296.0), alignment: .center)
                            VStack {
                                ScrollView(.horizontal, showsIndicators: false) {
                                    ZStack(alignment: .leading) {
                                        VStack {
                                            Text(StringConstants.kLblImage3)
                                                .font(FontScheme
                                                    .kRobotoRegular(size: getRelativeHeight(12.0)))
                                                .fontWeight(.regular)
                                                .foregroundColor(ColorConstants.Black900)
                                                .minimumScaleFactor(0.5)
                                                .multilineTextAlignment(.center)
                                                .frame(width: getRelativeWidth(118.0),
                                                       height: getRelativeHeight(16.0),
                                                       alignment: .center)
                                                .padding(.vertical, getRelativeHeight(67.0))
                                                .padding(.horizontal, getRelativeWidth(16.0))
                                        }
                                        .frame(width: getRelativeWidth(150.0),
                                               height: getRelativeWidth(150.0), alignment: .center)
                                        .background(ColorConstants.Black9000c)
                                        .padding(.vertical, getRelativeHeight(175.0))
                                        .padding(.horizontal, getRelativeWidth(251.0))
                                        ZStack(alignment: .center) {
                                            Image("img_image4")
                                                .resizable()
                                                .frame(width: UIScreen.main.bounds.width,
                                                       height: getRelativeHeight(500.0),
                                                       alignment: .center)
                                                .scaledToFit()
                                                .clipped()
                                            VStack(alignment: .leading, spacing: 0) {
                                                Text(StringConstants.kMsgCollectionSche)
                                                    .font(FontScheme
                                                        .kRobotoRegular(size: getRelativeHeight(12.0)))
                                                    .fontWeight(.regular)
                                                    .foregroundColor(ColorConstants.Black900)
                                                    .minimumScaleFactor(0.5)
                                                    .multilineTextAlignment(.leading)
                                                    .frame(width: getRelativeWidth(134.0),
                                                           height: getRelativeHeight(15.0),
                                                           alignment: .topLeading)
                                                Text(StringConstants.kMsgStayUpdatedWi)
                                                    .font(FontScheme
                                                        .kRobotoMedium(size: getRelativeHeight(16.0)))
                                                    .fontWeight(.medium)
                                                    .foregroundColor(ColorConstants.Black900)
                                                    .minimumScaleFactor(0.5)
                                                    .multilineTextAlignment(.leading)
                                                    .frame(width: getRelativeWidth(134.0),
                                                           height: getRelativeHeight(19.0),
                                                           alignment: .topLeading)
                                                    .padding(.top, getRelativeHeight(8.0))
                                            }
                                            .frame(width: getRelativeWidth(134.0),
                                                   height: getRelativeHeight(42.0),
                                                   alignment: .center)
                                            .padding(.top, getRelativeHeight(333.06))
                                            .padding(.horizontal, getRelativeWidth(259.0))
                                        }
                                        .hideNavigationBar()
                                        .frame(width: UIScreen.main.bounds.width,
                                               height: getRelativeHeight(500.0),
                                               alignment: .leading)
                                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                                   bottomLeft: 6.0,
                                                                   bottomRight: 6.0))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(500.0), alignment: .trailing)
                                    .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                               bottomLeft: 6.0, bottomRight: 6.0)
                                            .fill(ColorConstants.Black9000c))
                                }
                                .padding(.trailing, getRelativeWidth(106.0))
                            }
                            .frame(width: getRelativeWidth(150.0), height: getRelativeHeight(210.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Black90019,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(Color.clear.opacity(0.7)))
                            .padding(.leading, getRelativeWidth(8.0))
                        }
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(210.0),
                               alignment: .trailing)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(210.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(11.0))
                    VStack {
                        VStack(spacing: 0) {
                            ScrollView(.vertical, showsIndicators: false) {
                                LazyVStack {
                                    ForEach(0 ... 1, id: \.self) { index in
                                        RowtitleCell()
                                    }
                                }
                            }
                        }
                        .frame(width: getRelativeWidth(336.0), alignment: .center)
                        .padding(.horizontal, getRelativeWidth(12.0))
                        Divider()
                            .frame(width: getRelativeWidth(336.0), height: getRelativeHeight(1.0),
                                   alignment: .center)
                            .background(ColorConstants.Black90019)
                            .padding(.top, getRelativeHeight(8.0))
                            .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(193.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(20.0))
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLbl5)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(1.0))
                                Text(StringConstants.kLblHome)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(27.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .onTapGesture {
                                homeViewModel.nextScreen = "LandingPageView"
                            }
                            .frame(width: getRelativeWidth(27.0), height: getRelativeHeight(38.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            .padding(.leading, getRelativeWidth(31.0))
                            Spacer()
                            VStack {
                                Text(StringConstants.kLbl6)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(7.0))
                                Text(StringConstants.kLblRewards)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(38.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .frame(width: getRelativeWidth(38.0), height: getRelativeHeight(37.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            Spacer()
                            VStack {
                                Text(StringConstants.kLbl7)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(16.0))
                                Text(StringConstants.kLblNotifications)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(56.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .onTapGesture {
                                homeViewModel.nextScreen = "NotificationView"
                            }
                            .frame(width: getRelativeWidth(56.0), height: getRelativeHeight(37.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            Spacer()
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLbl8)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(2.0))
                                Text(StringConstants.kLblProfile)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(28.0),
                                           height: getRelativeHeight(12.0), alignment: .topLeading)
                            }
                            .onTapGesture {
                                homeViewModel.nextScreen = "ProfileView"
                            }
                            .frame(width: getRelativeWidth(28.0), height: getRelativeHeight(37.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            .padding(.trailing, getRelativeWidth(30.0))
                        }
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(50.0),
                               alignment: .leading)
                        .background(ColorConstants.WhiteA700)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(50.0),
                           alignment: .trailing)
                    .padding(.top, getRelativeHeight(11.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: TrashScannerView(),
                                   tag: "TrashScannerView",
                                   selection: $homeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: RecyclingCentersView(),
                                   tag: "RecyclingCentersView",
                                   selection: $homeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: SearchBarView(),
                                   tag: "SearchBarView",
                                   selection: $homeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: LandingPageView(),
                                   tag: "LandingPageView",
                                   selection: $homeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: NotificationView(),
                                   tag: "NotificationView",
                                   selection: $homeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: ProfileView(),
                                   tag: "ProfileView",
                                   selection: $homeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct HomeView_Previews: PreviewProvider {
    static var previews: some View {
        HomeView()
    }
}
