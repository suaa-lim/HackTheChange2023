import SwiftUI

struct CardCell: View {
    var body: some View {
        VStack {
            ZStack(alignment: .center) {
                ZStack(alignment: .leading) {
                    Divider()
                        .frame(width: getRelativeWidth(1.0), height: getRelativeHeight(150.0),
                               alignment: .leading)
                        .background(ColorConstants.Black9000c)
                        .padding(.trailing, getRelativeWidth(12.22))
                    Text(StringConstants.kLblImage1)
                        .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                        .fontWeight(.regular)
                        .foregroundColor(ColorConstants.Black900)
                        .minimumScaleFactor(0.5)
                        .multilineTextAlignment(.center)
                        .frame(width: getRelativeWidth(12.0), height: getRelativeHeight(30.0),
                               alignment: .center)
                }
                .hideNavigationBar()
                .frame(width: getRelativeWidth(12.0), height: getRelativeHeight(30.0),
                       alignment: .leading)
                .background(ColorConstants.Black9000c)
                .padding(.trailing, getRelativeWidth(136.78))
                Image("img_image2")
                    .resizable()
                    .frame(width: getRelativeWidth(147.0), height: getRelativeHeight(150.0),
                           alignment: .leading)
                    .scaledToFit()
            }
            .hideNavigationBar()
            .frame(width: getRelativeWidth(148.0), height: getRelativeWidth(150.0),
                   alignment: .leading)
            Text(StringConstants.kLblRecyclingGuide)
                .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                .fontWeight(.regular)
                .foregroundColor(ColorConstants.Black900)
                .minimumScaleFactor(0.5)
                .multilineTextAlignment(.leading)
                .frame(width: getRelativeWidth(83.0), height: getRelativeHeight(15.0),
                       alignment: .leading)
                .padding(.top, getRelativeHeight(9.0))
                .padding(.leading, getRelativeWidth(8.0))
                .padding(.trailing, getRelativeWidth(56.0))
            Text(StringConstants.kMsgScanAndLearn)
                .font(FontScheme.kRobotoMedium(size: getRelativeHeight(16.0)))
                .fontWeight(.medium)
                .foregroundColor(ColorConstants.Black900)
                .minimumScaleFactor(0.5)
                .multilineTextAlignment(.leading)
                .frame(width: getRelativeWidth(128.0), height: getRelativeHeight(19.0),
                       alignment: .leading)
                .padding(.vertical, getRelativeHeight(5.0))
                .padding(.leading, getRelativeWidth(8.0))
                .padding(.trailing, getRelativeWidth(11.0))
        }
        .frame(width: getRelativeWidth(148.0), alignment: .leading)
        .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0, bottomRight: 6.0)
            .stroke(ColorConstants.Black90019,
                    lineWidth: 1))
        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0, bottomRight: 6.0)
            .fill(Color.clear.opacity(0.7)))
        .hideNavigationBar()
    }
}

/* struct CardCell_Previews: PreviewProvider {

 static var previews: some View {
 			CardCell()
 }
 } */
