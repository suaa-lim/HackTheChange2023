import SwiftUI

struct RowframeCell: View {
    var body: some View {
        HStack {
            Text(StringConstants.kLbl9)
                .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                .fontWeight(.regular)
                .padding(.leading, getRelativeWidth(4.0))
                .padding(.top, getRelativeHeight(4.0))
                .foregroundColor(ColorConstants.Black900)
                .minimumScaleFactor(0.5)
                .multilineTextAlignment(.leading)
                .frame(width: getRelativeWidth(30.0), height: getRelativeWidth(32.0),
                       alignment: .leading)
                .background(ColorConstants.Black9000c)
            VStack(alignment: .leading, spacing: 0) {
                Text(StringConstants.kLblPaper)
                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(14.0)))
                    .fontWeight(.regular)
                    .foregroundColor(ColorConstants.Black900)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: getRelativeWidth(35.0), height: getRelativeHeight(17.0),
                           alignment: .leading)
                    .padding(.trailing)
                Text(StringConstants.kLblReduceWaste)
                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                    .fontWeight(.regular)
                    .foregroundColor(ColorConstants.Black9007f)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.leading)
                    .frame(width: getRelativeWidth(73.0), height: getRelativeHeight(15.0),
                           alignment: .leading)
            }
            .frame(width: getRelativeWidth(73.0), height: getRelativeHeight(32.0),
                   alignment: .leading)
            .padding(.leading, getRelativeWidth(8.0))
        }
        .frame(width: getRelativeWidth(113.0), alignment: .leading)
        .hideNavigationBar()
    }
}

/* struct RowframeCell_Previews: PreviewProvider {

 static var previews: some View {
 			RowframeCell()
 }
 } */
