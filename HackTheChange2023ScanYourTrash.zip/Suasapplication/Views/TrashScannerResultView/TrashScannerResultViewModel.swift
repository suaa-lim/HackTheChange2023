import Foundation
import SwiftUI

class TrashScannerResultViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
