import SwiftUI

struct LandingPageView: View {
    @StateObject var landingPageViewModel = LandingPageViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        ZStack(alignment: .center) {
                            ZStack(alignment: .center) {
                                Image("img_darkblue")
                                    .resizable()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(603.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                Text(StringConstants.kMsgTypePlasticC)
                                    .font(FontScheme
                                        .kRedHatTextMedium(size: getRelativeHeight(26.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.WhiteA700)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(159.0),
                                           height: getRelativeHeight(264.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(198.8))
                                    .padding(.horizontal, getRelativeWidth(107.71))
                            }
                            .hideNavigationBar()
                            .frame(width: UIScreen.main.bounds.width,
                                   height: getRelativeHeight(603.0), alignment: .topLeading)
                            .padding(.bottom, getRelativeHeight(32.0))
                            Button(action: {
                                landingPageViewModel.nextScreen = "SignUpView"
                            }, label: {
                                HStack(spacing: 0) {
                                    Text(StringConstants.kLblSignUp)
                                        .font(FontScheme
                                            .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                        .fontWeight(.medium)
                                        .padding(.horizontal, getRelativeWidth(30.0))
                                        .padding(.vertical, getRelativeHeight(20.0))
                                        .foregroundColor(ColorConstants.Teal100)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.center)
                                        .frame(width: getRelativeWidth(294.0),
                                               height: getRelativeHeight(64.0), alignment: .center)
                                        .background(RoundedCorners(topLeft: 32.0, topRight: 32.0,
                                                                   bottomLeft: 32.0,
                                                                   bottomRight: 32.0)
                                                .fill(ColorConstants.Gray800))
                                        .padding(.top, getRelativeHeight(571.0))
                                        .padding(.horizontal, getRelativeWidth(41.0))
                                }
                            })
                            .frame(width: getRelativeWidth(294.0), height: getRelativeHeight(64.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 32.0, topRight: 32.0,
                                                       bottomLeft: 32.0, bottomRight: 32.0)
                                    .fill(ColorConstants.Gray800))
                            .padding(.top, getRelativeHeight(571.0))
                            .padding(.horizontal, getRelativeWidth(41.0))
                        }
                        .hideNavigationBar()
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(635.0),
                               alignment: .leading)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(635.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(52.0))
                    VStack {
                        Button(action: {
                            landingPageViewModel.nextScreen = "SignInView"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgIHaveAnAccou)
                                    .font(FontScheme
                                        .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                    .fontWeight(.medium)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(20.0))
                                    .foregroundColor(ColorConstants.Gray800)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(294.0),
                                           height: getRelativeHeight(64.0), alignment: .topLeading)
                                    .overlay(RoundedCorners(topLeft: 32.0, topRight: 32.0,
                                                            bottomLeft: 32.0, bottomRight: 32.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 3))
                                    .background(RoundedCorners(topLeft: 32.0, topRight: 32.0,
                                                               bottomLeft: 32.0, bottomRight: 32.0)
                                            .fill(Color.clear.opacity(0.7)))
                                    .padding(.horizontal, getRelativeWidth(41.0))
                            }
                        })
                        .frame(width: getRelativeWidth(294.0), height: getRelativeHeight(64.0),
                               alignment: .topLeading)
                        .overlay(RoundedCorners(topLeft: 32.0, topRight: 32.0, bottomLeft: 32.0,
                                                bottomRight: 32.0)
                                .stroke(ColorConstants.Gray700,
                                        lineWidth: 3))
                        .background(RoundedCorners(topLeft: 32.0, topRight: 32.0, bottomLeft: 32.0,
                                                   bottomRight: 32.0)
                                .fill(Color.clear.opacity(0.7)))
                        .padding(.horizontal, getRelativeWidth(41.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(64.0),
                           alignment: .leading)
                    .padding(.vertical, getRelativeHeight(16.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: SignUpView(),
                                   tag: "SignUpView",
                                   selection: $landingPageViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: SignInView(),
                                   tag: "SignInView",
                                   selection: $landingPageViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct LandingPageView_Previews: PreviewProvider {
    static var previews: some View {
        LandingPageView()
    }
}
