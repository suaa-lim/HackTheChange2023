import Foundation
import SwiftUI

class LandingPageViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
