import Foundation
import SwiftUI

class RecyclingCentersViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
    @Published var frameText: String = ""
}
