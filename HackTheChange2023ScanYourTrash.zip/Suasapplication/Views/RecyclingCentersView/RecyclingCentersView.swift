import SwiftUI

struct RecyclingCentersView: View {
    @StateObject var recyclingCentersViewModel = RecyclingCentersViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack {
                                HStack {
                                    Image("img_wifi")
                                        .resizable()
                                        .frame(width: getRelativeWidth(18.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(256.0))
                                    Image("img_cellular")
                                        .resizable()
                                        .frame(width: getRelativeWidth(14.0),
                                               height: getRelativeWidth(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                    Image("img_battery")
                                        .resizable()
                                        .frame(width: getRelativeWidth(9.0),
                                               height: getRelativeHeight(14.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(5.0))
                                        .padding(.leading, getRelativeWidth(9.0))
                                    Image("img_time")
                                        .resizable()
                                        .frame(width: getRelativeWidth(33.0),
                                               height: getRelativeHeight(10.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.vertical, getRelativeHeight(6.0))
                                        .padding(.horizontal, getRelativeWidth(8.0))
                                }
                                .onTapGesture {
                                    recyclingCentersViewModel.nextScreen = "HomeView"
                                }
                                .frame(width: UIScreen.main.bounds.width,
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .background(ColorConstants.Green200)
                                HStack {
                                    Image("img_arrowleft_black_900")
                                        .resizable()
                                        .frame(width: getRelativeWidth(10.0),
                                               height: getRelativeHeight(18.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                        .padding(.bottom, getRelativeHeight(4.0))
                                        .onTapGesture {
                                            self.presentationMode.wrappedValue.dismiss()
                                        }
                                    Text(StringConstants.kMsgRecyclingCente)
                                        .font(FontScheme
                                            .kRobotoMedium(size: getRelativeHeight(20.0)))
                                        .fontWeight(.medium)
                                        .foregroundColor(ColorConstants.Black900)
                                        .minimumScaleFactor(0.5)
                                        .multilineTextAlignment(.leading)
                                        .frame(width: getRelativeWidth(161.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .padding(.leading, getRelativeWidth(15.0))
                                }
                                .frame(width: getRelativeWidth(186.0),
                                       height: getRelativeHeight(24.0), alignment: .leading)
                                .padding(.top, getRelativeHeight(13.0))
                                .padding(.horizontal, getRelativeWidth(15.0))
                            }
                        }
                        .frame(width: UIScreen.main.bounds.width - 20,
                               height: getRelativeHeight(72.0), alignment: .leading)
                        .background(ColorConstants.Green200)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(72.0),
                           alignment: .leading)
                    VStack {
                        HStack {
                            ZStack {
                                Image("img_search")
                                    .resizable()
                                    .frame(width: getRelativeWidth(16.0),
                                           height: getRelativeWidth(16.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.top, getRelativeHeight(5.67))
                                    .padding(.bottom, getRelativeHeight(6.33))
                                    .padding(.horizontal, getRelativeWidth(9.67))
                            }
                            .hideNavigationBar()
                            .frame(width: getRelativeWidth(36.0), height: getRelativeHeight(28.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.Black900))
                            .padding(.vertical, getRelativeHeight(8.0))
                            .padding(.leading, getRelativeWidth(6.0))
                            HStack {
                                TextField(StringConstants.kLblFindLocation,
                                          text: $recyclingCentersViewModel.frameText)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Black900)
                                    .padding()
                            }
                            .frame(width: getRelativeWidth(198.0), height: getRelativeHeight(40.0),
                                   alignment: .center)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.Bluegray100))
                            .padding(.horizontal, getRelativeWidth(4.0))
                        }
                        .frame(width: getRelativeWidth(248.0), height: getRelativeHeight(44.0),
                               alignment: .center)
                        .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                bottomRight: 6.0)
                                .stroke(ColorConstants.Black90019,
                                        lineWidth: 1))
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(Color.clear.opacity(0.7)))
                        .padding(.horizontal, getRelativeWidth(21.0))
                        Text(StringConstants.kMsgFindRecycling2)
                            .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Black9007f)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(164.0), height: getRelativeHeight(14.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(5.0))
                            .padding(.horizontal, getRelativeWidth(21.0))
                        ZStack(alignment: .center) {
                            Image("img_image")
                                .resizable()
                                .frame(width: getRelativeWidth(317.0),
                                       height: getRelativeHeight(237.0), alignment: .center)
                                .scaledToFit()
                                .clipped()
                                .background(RoundedCorners(topLeft: 6.0, topRight: 6.0,
                                                           bottomLeft: 6.0, bottomRight: 6.0))
                            VStack {
                                Image("img_shape")
                                    .resizable()
                                    .frame(width: getRelativeWidth(16.0),
                                           height: getRelativeHeight(21.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.horizontal, getRelativeWidth(133.0))
                                Text(StringConstants.kMsgFindNearbyRec)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(16.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(282.0),
                                           height: getRelativeHeight(44.0), alignment: .center)
                                    .padding(.top, getRelativeHeight(9.0))
                            }
                            .frame(width: getRelativeWidth(282.0), height: getRelativeHeight(75.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(96.0))
                            .padding(.horizontal, getRelativeWidth(17.57))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(317.0), height: getRelativeHeight(237.0),
                               alignment: .center)
                        .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                   bottomRight: 6.0)
                                .fill(ColorConstants.Black9000c))
                        .padding(.top, getRelativeHeight(12.0))
                        .padding(.horizontal, getRelativeWidth(21.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(313.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(12.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Text(StringConstants.kMsgRecommendedRec)
                            .font(FontScheme.kRobotoMedium(size: getRelativeHeight(18.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Black900)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(271.0), height: getRelativeHeight(22.0),
                                   alignment: .topLeading)
                            .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(22.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(18.0))
                    VStack {
                        HStack {
                            VStack {
                                ZStack(alignment: .center) {
                                    ZStack(alignment: .bottomLeading) {
                                        Divider()
                                            .frame(width: getRelativeWidth(1.0),
                                                   height: getRelativeHeight(113.0),
                                                   alignment: .leading)
                                            .background(ColorConstants.Black9000c)
                                            .padding(.trailing, getRelativeWidth(63.0))
                                        Text(StringConstants.kMsgRecyclingCente2)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(12.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.center)
                                            .frame(width: getRelativeWidth(13.0),
                                                   height: getRelativeHeight(62.0),
                                                   alignment: .center)
                                            .padding(.top, getRelativeHeight(50.47))
                                            .padding(.trailing, getRelativeWidth(51.0))
                                        VStack {
                                            Text(StringConstants.kLblOpenNow)
                                                .font(FontScheme
                                                    .kRobotoMedium(size: getRelativeHeight(12.0)))
                                                .fontWeight(.medium)
                                                .foregroundColor(ColorConstants.Black900)
                                                .minimumScaleFactor(0.5)
                                                .multilineTextAlignment(.leading)
                                                .frame(width: getRelativeWidth(56.0),
                                                       height: getRelativeHeight(15.0),
                                                       alignment: .topLeading)
                                                .padding(.top, getRelativeHeight(5.0))
                                                .padding(.horizontal, getRelativeWidth(4.0))
                                        }
                                        .frame(width: getRelativeWidth(64.0),
                                               height: getRelativeHeight(24.0),
                                               alignment: .topLeading)
                                        .background(RoundedCorners(topLeft: 6.0, bottomRight: 6.0)
                                            .fill(ColorConstants.Black9000c))
                                        .padding(.bottom, getRelativeHeight(89.0))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(64.0),
                                           height: getRelativeHeight(113.0), alignment: .topLeading)
                                    .background(ColorConstants.Black9000c)
                                    .padding(.bottom, getRelativeHeight(51.0))
                                    .padding(.trailing, getRelativeWidth(101.0))
                                    Image("img_image7")
                                        .resizable()
                                        .frame(width: getRelativeWidth(164.0),
                                               height: getRelativeWidth(164.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                }
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(165.0),
                                       height: getRelativeHeight(164.0), alignment: .leading)
                                Text(StringConstants.kMsgGreenPlanetRe)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(122.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(9.0))
                                    .padding(.leading, getRelativeWidth(8.0))
                                    .padding(.trailing, getRelativeWidth(34.0))
                                Text(StringConstants.kMsgAddress123Ma)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(16.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(145.0),
                                           height: getRelativeHeight(19.0), alignment: .topLeading)
                                    .padding(.vertical, getRelativeHeight(5.0))
                                    .padding(.leading, getRelativeWidth(8.0))
                                    .padding(.trailing, getRelativeWidth(11.0))
                            }
                            .frame(width: getRelativeWidth(165.0), height: getRelativeHeight(224.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Black90019,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(Color.clear.opacity(0.7)))
                            Spacer()
                            VStack {
                                ZStack(alignment: .leading) {
                                    ZStack(alignment: .center) {
                                        ZStack {}
                                            .hideNavigationBar()
                                            .frame(width: getRelativeWidth(165.0),
                                                   height: getRelativeHeight(164.0),
                                                   alignment: .leading)
                                            .background(ColorConstants.Black9000c)
                                        Text(StringConstants.kMsgRecyclingCente2)
                                            .font(FontScheme
                                                .kRobotoRegular(size: getRelativeHeight(12.0)))
                                            .fontWeight(.regular)
                                            .foregroundColor(ColorConstants.Black900)
                                            .minimumScaleFactor(0.5)
                                            .multilineTextAlignment(.leading)
                                            .frame(width: getRelativeWidth(88.0),
                                                   height: getRelativeHeight(15.0),
                                                   alignment: .topLeading)
                                            .padding(.top, getRelativeHeight(74.78))
                                            .padding(.bottom, getRelativeHeight(73.22))
                                            .padding(.horizontal, getRelativeWidth(38.84))
                                    }
                                    .hideNavigationBar()
                                    .frame(width: getRelativeWidth(165.0),
                                           height: getRelativeHeight(163.0), alignment: .leading)
                                    Image("img_image8")
                                        .resizable()
                                        .frame(width: getRelativeWidth(165.0),
                                               height: getRelativeHeight(164.0), alignment: .center)
                                        .scaledToFit()
                                        .clipped()
                                }
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(165.0),
                                       height: getRelativeHeight(164.0), alignment: .leading)
                                .background(ColorConstants.Black9000c)
                                Text(StringConstants.kMsgEcoRecyclingS)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(12.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(127.0),
                                           height: getRelativeHeight(15.0), alignment: .topLeading)
                                    .padding(.top, getRelativeHeight(8.0))
                                    .padding(.horizontal, getRelativeWidth(8.0))
                                Text(StringConstants.kMsgAddress456El)
                                    .font(FontScheme.kRobotoMedium(size: getRelativeHeight(16.0)))
                                    .fontWeight(.medium)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(137.0),
                                           height: getRelativeHeight(19.0), alignment: .topLeading)
                                    .padding(.vertical, getRelativeHeight(5.0))
                                    .padding(.horizontal, getRelativeWidth(8.0))
                            }
                            .frame(width: getRelativeWidth(165.0), height: getRelativeHeight(224.0),
                                   alignment: .center)
                            .overlay(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                    bottomRight: 6.0)
                                    .stroke(ColorConstants.Black90019,
                                            lineWidth: 1))
                            .background(RoundedCorners(topLeft: 6.0, topRight: 6.0, bottomLeft: 6.0,
                                                       bottomRight: 6.0)
                                    .fill(Color.clear.opacity(0.7)))
                        }
                        .frame(width: getRelativeWidth(338.0), height: getRelativeHeight(224.0),
                               alignment: .center)
                        .padding(.horizontal, getRelativeWidth(11.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(224.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(12.0))
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLbl5)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(1.0))
                                    .onTapGesture {
                                        recyclingCentersViewModel.nextScreen = "HomeView"
                                    }
                                Text(StringConstants.kLblHome)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(27.0),
                                           height: getRelativeHeight(12.0), alignment: .center)
                            }
                            .onTapGesture {
                                recyclingCentersViewModel.nextScreen = "HomeView"
                            }
                            .frame(width: getRelativeWidth(27.0), height: getRelativeHeight(38.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            .padding(.leading, getRelativeWidth(31.0))
                            Spacer()
                            VStack {
                                Text(StringConstants.kLbl6)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(7.0))
                                Text(StringConstants.kLblRewards)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(38.0),
                                           height: getRelativeHeight(12.0), alignment: .center)
                            }
                            .frame(width: getRelativeWidth(38.0), height: getRelativeHeight(37.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            Spacer()
                            VStack {
                                Text(StringConstants.kLbl7)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(16.0))
                                Text(StringConstants.kLblNotifications)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(56.0),
                                           height: getRelativeHeight(12.0), alignment: .center)
                            }
                            .onTapGesture {
                                recyclingCentersViewModel.nextScreen = "NotificationView"
                            }
                            .frame(width: getRelativeWidth(56.0), height: getRelativeHeight(37.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            Spacer()
                            VStack(alignment: .leading, spacing: 0) {
                                Text(StringConstants.kLbl8)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(20.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(22.0),
                                           height: getRelativeHeight(24.0), alignment: .topLeading)
                                    .padding(.horizontal, getRelativeWidth(2.0))
                                Text(StringConstants.kLblProfile)
                                    .font(FontScheme.kRobotoRegular(size: getRelativeHeight(10.0)))
                                    .fontWeight(.regular)
                                    .foregroundColor(ColorConstants.Black900)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.center)
                                    .frame(width: getRelativeWidth(28.0),
                                           height: getRelativeHeight(12.0), alignment: .center)
                            }
                            .onTapGesture {
                                recyclingCentersViewModel.nextScreen = "ProfileView"
                            }
                            .frame(width: getRelativeWidth(28.0), height: getRelativeHeight(37.0),
                                   alignment: .center)
                            .padding(.top, getRelativeHeight(6.0))
                            .padding(.bottom, getRelativeHeight(5.0))
                            .padding(.trailing, getRelativeWidth(30.0))
                        }
                        .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(50.0),
                               alignment: .leading)
                        .background(ColorConstants.WhiteA700)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(50.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(16.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: HomeView(),
                                   tag: "HomeView",
                                   selection: $recyclingCentersViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: NotificationView(),
                                   tag: "NotificationView",
                                   selection: $recyclingCentersViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: ProfileView(),
                                   tag: "ProfileView",
                                   selection: $recyclingCentersViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct RecyclingCentersView_Previews: PreviewProvider {
    static var previews: some View {
        RecyclingCentersView()
    }
}
