import Foundation
import SwiftUI

class DeadEndViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
