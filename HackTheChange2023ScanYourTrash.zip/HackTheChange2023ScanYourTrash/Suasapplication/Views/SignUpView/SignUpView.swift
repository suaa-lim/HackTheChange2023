import SwiftUI

struct SignUpView: View {
    @StateObject var signUpViewModel = SignUpViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    VStack(alignment: .leading, spacing: 0) {
                        HStack {
                            VStack {
                                Image("img_top")
                                    .resizable()
                                    .frame(width: UIScreen.main.bounds.width,
                                           height: getRelativeHeight(24.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                Image("img_arrowleft")
                                    .resizable()
                                    .frame(width: getRelativeWidth(92.0),
                                           height: getRelativeHeight(18.0), alignment: .center)
                                    .scaledToFit()
                                    .clipped()
                                    .padding(.top, getRelativeHeight(14.0))
                                    .padding(.horizontal, getRelativeWidth(15.0))
                                    .onTapGesture {
                                        self.presentationMode.wrappedValue.dismiss()
                                    }
                            }
                        }
                        .frame(width: UIScreen.main.bounds.width - 20,
                               height: getRelativeHeight(72.0), alignment: .leading)
                        .background(ColorConstants.Green200)
                        .shadow(color: ColorConstants.Black9001e, radius: 6, x: 0, y: 0)
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(72.0),
                           alignment: .leading)
                    VStack {
                        ZStack(alignment: .trailing) {
                            VStack(alignment: .leading, spacing: 0) {
                                Group {
                                    HStack {
                                        TextField(StringConstants.kLblFirstName,
                                                  text: $signUpViewModel.languageText)
                                            .font(FontScheme
                                                .kInterRegular(size: getRelativeHeight(16.0)))
                                            .foregroundColor(ColorConstants.Black900)
                                            .padding()
                                            .keyboardType(.alphabet)
                                    }
                                    .onChange(of: signUpViewModel.languageText) { newValue in

                                        signUpViewModel.isValidLanguageText = newValue
                                            .isText(isMandatory: false)
                                    }
                                    .frame(width: getRelativeWidth(198.0),
                                           height: getRelativeHeight(40.0), alignment: .leading)
                                    .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                               bottomLeft: 4.0, bottomRight: 4.0)
                                            .fill(ColorConstants.Orange50))
                                    if !signUpViewModel.isValidLanguageText {
                                        Text("Please enter valid text.")
                                            .foregroundColor(Color.red)
                                            .font(FontScheme
                                                .kInterRegular(size: getRelativeHeight(16.0)))
                                            .frame(width: getRelativeWidth(198.0),
                                                   height: getRelativeHeight(40.0),
                                                   alignment: .leading)
                                    }
                                }
                                Group {
                                    HStack {
                                        TextField(StringConstants.kLblLastName,
                                                  text: $signUpViewModel.frameText)
                                            .font(FontScheme
                                                .kInterRegular(size: getRelativeHeight(16.0)))
                                            .foregroundColor(ColorConstants.Black900)
                                            .padding()
                                            .keyboardType(.alphabet)
                                    }
                                    .onChange(of: signUpViewModel.frameText) { newValue in

                                        signUpViewModel.isValidFrameText = newValue
                                            .isText(isMandatory: false)
                                    }
                                    .frame(width: getRelativeWidth(198.0),
                                           height: getRelativeHeight(40.0), alignment: .leading)
                                    .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                               bottomLeft: 4.0, bottomRight: 4.0)
                                            .fill(ColorConstants.Orange50))
                                    .padding(.top, getRelativeHeight(22.0))
                                    if !signUpViewModel.isValidFrameText {
                                        Text("Please enter valid text.")
                                            .foregroundColor(Color.red)
                                            .font(FontScheme
                                                .kInterRegular(size: getRelativeHeight(16.0)))
                                            .frame(width: getRelativeWidth(198.0),
                                                   height: getRelativeHeight(40.0),
                                                   alignment: .leading)
                                    }
                                }
                            }
                            .frame(width: getRelativeWidth(198.0), height: getRelativeHeight(102.0),
                                   alignment: .leading)
                            .padding(.trailing, getRelativeWidth(74.0))
                            Divider()
                                .frame(width: getRelativeWidth(260.0),
                                       height: getRelativeHeight(3.0), alignment: .trailing)
                                .background(ColorConstants.Bluegray900)
                                .padding(.leading, getRelativeWidth(12.0))
                        }
                        .hideNavigationBar()
                        .frame(width: getRelativeWidth(272.0), height: getRelativeHeight(102.0),
                               alignment: .center)
                        .padding(.horizontal, getRelativeWidth(50.0))
                        Divider()
                            .frame(width: getRelativeWidth(260.0), height: getRelativeHeight(3.0),
                                   alignment: .center)
                            .background(ColorConstants.Bluegray900)
                            .padding(.horizontal, getRelativeWidth(50.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(107.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(7.0))
                    VStack(alignment: .leading, spacing: 0) {
                        Group {
                            HStack {
                                TextField(StringConstants.kLblEmailAddress,
                                          text: $signUpViewModel.frameoneText)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Black900)
                                    .padding()
                                    .keyboardType(.emailAddress)
                            }
                            .onChange(of: signUpViewModel.frameoneText) { newValue in

                                signUpViewModel.isValidFrameoneText = newValue
                                    .isValidEmail(isMandatory: true)
                            }
                            .frame(width: getRelativeWidth(198.0), height: getRelativeHeight(40.0),
                                   alignment: .leading)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.Orange50))
                            .padding(.horizontal, getRelativeWidth(53.0))
                            if !signUpViewModel.isValidFrameoneText {
                                Text("Please enter valid email.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(16.0)))
                                    .frame(width: getRelativeWidth(198.0),
                                           height: getRelativeHeight(40.0), alignment: .leading)
                            }
                        }
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(40.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(8.0))
                    VStack {
                        Divider()
                            .frame(width: getRelativeWidth(260.0), height: getRelativeHeight(3.0),
                                   alignment: .center)
                            .background(ColorConstants.Bluegray900)
                            .padding(.leading, getRelativeWidth(62.0))
                            .padding(.trailing, getRelativeWidth(53.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(3.0),
                           alignment: .leading)
                    VStack(alignment: .leading, spacing: 0) {
                        Group {
                            HStack {
                                TextField(StringConstants.kMsgPassword8Ch,
                                          text: $signUpViewModel.frametwoText)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(16.0)))
                                    .foregroundColor(ColorConstants.Black900)
                                    .padding()
                                    .keyboardType(.default)
                            }
                            .onChange(of: signUpViewModel.frametwoText) { newValue in

                                signUpViewModel.isValidFrametwoText = newValue
                                    .isValidPassword(isMandatory: true)
                            }
                            .frame(width: getRelativeWidth(242.0), height: getRelativeHeight(40.0),
                                   alignment: .leading)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.Orange50))
                            .padding(.horizontal, getRelativeWidth(47.0))
                            if !signUpViewModel.isValidFrametwoText {
                                Text("Please enter valid password.")
                                    .foregroundColor(Color.red)
                                    .font(FontScheme.kInterRegular(size: getRelativeHeight(16.0)))
                                    .frame(width: getRelativeWidth(242.0),
                                           height: getRelativeHeight(40.0), alignment: .leading)
                            }
                        }
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(40.0),
                           alignment: .leading)
                    .padding(.top, getRelativeHeight(8.0))
                    VStack {
                        Divider()
                            .frame(width: getRelativeWidth(260.0), height: getRelativeHeight(3.0),
                                   alignment: .center)
                            .background(ColorConstants.Bluegray900)
                            .padding(.horizontal, getRelativeWidth(40.0))
                        Button(action: {
                            signUpViewModel.nextScreen = "HomeView"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kLblGetStarted)
                                    .font(FontScheme
                                        .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                    .fontWeight(.medium)
                                    .padding(.horizontal, getRelativeWidth(30.0))
                                    .padding(.vertical, getRelativeHeight(20.0))
                                    .foregroundColor(ColorConstants.Bluegray500)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(294.0),
                                           height: getRelativeHeight(64.0), alignment: .topLeading)
                                    .background(RoundedCorners(topLeft: 32.0, topRight: 32.0,
                                                               bottomLeft: 32.0, bottomRight: 32.0)
                                            .fill(ColorConstants.Gray800))
                                    .padding(.top, getRelativeHeight(24.0))
                                    .padding(.horizontal, getRelativeWidth(40.0))
                            }
                        })
                        .frame(width: getRelativeWidth(294.0), height: getRelativeHeight(64.0),
                               alignment: .topLeading)
                        .background(RoundedCorners(topLeft: 32.0, topRight: 32.0, bottomLeft: 32.0,
                                                   bottomRight: 32.0)
                                .fill(ColorConstants.Gray800))
                        .padding(.top, getRelativeHeight(24.0))
                        .padding(.horizontal, getRelativeWidth(40.0))
                        Text(StringConstants.kLblOr)
                            .font(FontScheme.kRedHatTextMedium(size: getRelativeHeight(18.0)))
                            .fontWeight(.medium)
                            .foregroundColor(ColorConstants.Gray800)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.leading)
                            .frame(width: getRelativeWidth(27.0), height: getRelativeHeight(24.0),
                                   alignment: .topLeading)
                            .padding(.top, getRelativeHeight(10.0))
                            .padding(.horizontal, getRelativeWidth(40.0))
                        Button(action: {
                            signUpViewModel.nextScreen = "SignInView"
                        }, label: {
                            HStack(spacing: 0) {
                                Text(StringConstants.kMsgAlreadyHaveAn)
                                    .font(FontScheme
                                        .kRedHatTextMedium(size: getRelativeHeight(18.0)))
                                    .fontWeight(.medium)
                                    .padding(.horizontal, getRelativeWidth(10.0))
                                    .padding(.vertical, getRelativeHeight(20.0))
                                    .foregroundColor(ColorConstants.Gray800)
                                    .minimumScaleFactor(0.5)
                                    .multilineTextAlignment(.leading)
                                    .frame(width: getRelativeWidth(294.0),
                                           height: getRelativeHeight(64.0), alignment: .topLeading)
                                    .overlay(RoundedCorners(topLeft: 32.0, topRight: 32.0,
                                                            bottomLeft: 32.0, bottomRight: 32.0)
                                            .stroke(ColorConstants.Gray700,
                                                    lineWidth: 3))
                                    .background(RoundedCorners(topLeft: 32.0, topRight: 32.0,
                                                               bottomLeft: 32.0, bottomRight: 32.0)
                                            .fill(Color.clear.opacity(0.7)))
                                    .padding(.top, getRelativeHeight(14.0))
                                    .padding(.horizontal, getRelativeWidth(40.0))
                            }
                        })
                        .frame(width: getRelativeWidth(294.0), height: getRelativeHeight(64.0),
                               alignment: .topLeading)
                        .overlay(RoundedCorners(topLeft: 32.0, topRight: 32.0, bottomLeft: 32.0,
                                                bottomRight: 32.0)
                                .stroke(ColorConstants.Gray700,
                                        lineWidth: 3))
                        .background(RoundedCorners(topLeft: 32.0, topRight: 32.0, bottomLeft: 32.0,
                                                   bottomRight: 32.0)
                                .fill(Color.clear.opacity(0.7)))
                        .padding(.top, getRelativeHeight(14.0))
                        .padding(.horizontal, getRelativeWidth(40.0))
                    }
                    .frame(width: UIScreen.main.bounds.width, height: getRelativeHeight(204.0),
                           alignment: .leading)
                    .padding(.vertical, getRelativeHeight(3.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: SignInView(),
                                   tag: "SignInView",
                                   selection: $signUpViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                    NavigationLink(destination: HomeView(),
                                   tag: "HomeView",
                                   selection: $signUpViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
    }
}

struct SignUpView_Previews: PreviewProvider {
    static var previews: some View {
        SignUpView()
    }
}
