import SwiftUI

struct DeadEndView: View {
    @StateObject var deadEndViewModel = DeadEndViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        VStack {
            VStack {
                Image("img_icon11")
                    .resizable()
                    .frame(width: getRelativeWidth(132.0), height: getRelativeHeight(204.0),
                           alignment: .center)
                    .scaledToFit()
                    .clipped()
                    .background(RoundedCorners(topLeft: 50.0, topRight: 50.0, bottomLeft: 50.0,
                                               bottomRight: 50.0))
                    .padding(.top, getRelativeHeight(144.0))
                    .padding(.horizontal, getRelativeWidth(78.0))
                Text(StringConstants.kMsgThankYouForU)
                    .font(FontScheme.kRedHatTextRomanBold(size: getRelativeHeight(18.0)))
                    .fontWeight(.bold)
                    .foregroundColor(ColorConstants.WhiteA700)
                    .minimumScaleFactor(0.5)
                    .multilineTextAlignment(.center)
                    .frame(width: getRelativeWidth(217.0), height: getRelativeHeight(48.0),
                           alignment: .center)
                    .padding(.vertical, getRelativeHeight(33.0))
                    .padding(.horizontal, getRelativeWidth(78.0))
            }
            .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
            .background(ColorConstants.Bluegray500)
            .padding(.top, getRelativeHeight(30.0))
            .padding(.bottom, getRelativeHeight(10.0))
        }
        .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
        .background(ColorConstants.Bluegray500)
        .ignoresSafeArea()
        .hideNavigationBar()
    }
}

struct DeadEndView_Previews: PreviewProvider {
    static var previews: some View {
        DeadEndView()
    }
}
