import SwiftUI

struct WelcomeView: View {
    @StateObject var welcomeViewModel = WelcomeViewModel()
    @Environment(\.presentationMode) var presentationMode: Binding<PresentationMode>
    var body: some View {
        NavigationView {
            VStack {
                VStack {
                    ZStack(alignment: .center) {
                        Text(StringConstants.kLblScanYourTrash)
                            .font(FontScheme.kSquadaOneRegular(size: getRelativeHeight(100.0)))
                            .fontWeight(.regular)
                            .foregroundColor(ColorConstants.Gray800)
                            .minimumScaleFactor(0.5)
                            .multilineTextAlignment(.center)
                            .frame(width: getRelativeWidth(233.0), height: getRelativeHeight(279.0),
                                   alignment: .center)
                        VStack(alignment: .leading, spacing: 0) {
                            VStack {
                                ZStack {}
                                    .hideNavigationBar()
                                    .onTapGesture {
                                        welcomeViewModel.nextScreen = "LandingPageView"
                                    }
                                    .frame(width: getRelativeWidth(208.0),
                                           height: getRelativeHeight(8.0), alignment: .leading)
                                    .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                               bottomLeft: 4.0, bottomRight: 4.0)
                                            .fill(ColorConstants.Bluegray300))
                            }
                            .frame(width: getRelativeWidth(208.0), height: getRelativeHeight(8.0),
                                   alignment: .leading)
                            .background(RoundedCorners(topLeft: 4.0, topRight: 4.0, bottomLeft: 4.0,
                                                       bottomRight: 4.0)
                                    .fill(ColorConstants.LightGreenA700))
                            ZStack {}
                                .hideNavigationBar()
                                .frame(width: getRelativeWidth(208.0),
                                       height: getRelativeHeight(8.0), alignment: .leading)
                                .background(RoundedCorners(topLeft: 4.0, topRight: 4.0,
                                                           bottomLeft: 4.0, bottomRight: 4.0)
                                        .fill(ColorConstants.Bluegray300))
                                .padding(.top, getRelativeHeight(78.0))
                        }
                        .frame(width: getRelativeWidth(208.0), height: getRelativeHeight(94.0),
                               alignment: .center)
                        .padding(.vertical, getRelativeHeight(90.9))
                        .padding(.horizontal, getRelativeWidth(12.0))
                    }
                    .hideNavigationBar()
                    .frame(width: getRelativeWidth(233.0), height: getRelativeHeight(279.0),
                           alignment: .center)
                    .padding(.vertical, getRelativeHeight(277.0))
                    .padding(.horizontal, getRelativeWidth(71.0))
                }
                .frame(width: UIScreen.main.bounds.width, alignment: .topLeading)
                .background(ColorConstants.Orange50)
                .padding(.top, getRelativeHeight(30.0))
                .padding(.bottom, getRelativeHeight(10.0))
                Group {
                    NavigationLink(destination: LandingPageView(),
                                   tag: "LandingPageView",
                                   selection: $welcomeViewModel.nextScreen,
                                   label: {
                                       EmptyView()
                                   })
                }
            }
            .frame(width: UIScreen.main.bounds.width, height: UIScreen.main.bounds.height)
            .background(ColorConstants.Orange50)
            .ignoresSafeArea()
            .hideNavigationBar()
        }
        .hideNavigationBar()
        .onAppear {
            welcomeViewModel.nextScreen = "LandingPageView"
        }
    }
}

struct WelcomeView_Previews: PreviewProvider {
    static var previews: some View {
        WelcomeView()
    }
}
