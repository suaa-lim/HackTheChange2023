import Foundation
import SwiftUI

class SearchBarViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
