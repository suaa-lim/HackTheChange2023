import Foundation
import SwiftUI

class ResultViewModel: ObservableObject {
    @Published var nextScreen: String? = nil
}
