import Foundation
import SwiftUI

class FontScheme: NSObject {
    static func kSquadaOneRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kSquadaOneRegular, size: size)
    }

    static func kRedHatTextMedium(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRedHatTextMedium, size: size)
    }

    static func kRedHatTextBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRedHatTextBold, size: size)
    }

    static func kRedHatTextRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRedHatTextRegular, size: size)
    }

    static func kRedHatTextRomanBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRedHatTextRomanBold, size: size)
    }

    static func kInterRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kInterRegular, size: size)
    }

    static func kRobotoMedium(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRobotoMedium, size: size)
    }

    static func kRobotoRegular(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRobotoRegular, size: size)
    }

    static func kRobotoItalicBold(size: CGFloat) -> Font {
        return Font.custom(FontConstant.kRobotoItalicBold, size: size)
    }

    static func fontFromConstant(fontName: String, size: CGFloat) -> Font {
        var result = Font.system(size: size)

        switch fontName {
        case "kSquadaOneRegular":
            result = self.kSquadaOneRegular(size: size)
        case "kRedHatTextMedium":
            result = self.kRedHatTextMedium(size: size)
        case "kRedHatTextBold":
            result = self.kRedHatTextBold(size: size)
        case "kRedHatTextRegular":
            result = self.kRedHatTextRegular(size: size)
        case "kRedHatTextRomanBold":
            result = self.kRedHatTextRomanBold(size: size)
        case "kInterRegular":
            result = self.kInterRegular(size: size)
        case "kRobotoMedium":
            result = self.kRobotoMedium(size: size)
        case "kRobotoRegular":
            result = self.kRobotoRegular(size: size)
        case "kRobotoItalicBold":
            result = self.kRobotoItalicBold(size: size)
        default:
            result = self.kSquadaOneRegular(size: size)
        }
        return result
    }

    enum FontConstant {
        /**
         * Please Add this fonts Manually
         */
        static let kSquadaOneRegular: String = "SquadaOne-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kRedHatTextMedium: String = "RedHatText-Medium"
        /**
         * Please Add this fonts Manually
         */
        static let kRedHatTextBold: String = "RedHatText-Bold"
        /**
         * Please Add this fonts Manually
         */
        static let kRedHatTextRegular: String = "RedHatText-Regular"
        /**
         * Please Add this fonts Manually
         */
        static let kRedHatTextRomanBold: String = "RedHatTextRoman-Bold"
        /**
         * Please Add this fonts Manually
         */
        static let kInterRegular: String = "InterRegular"
        /**
         * Please Add this fonts Manually
         */
        static let kRobotoMedium: String = "RobotoMedium"
        /**
         * Please Add this fonts Manually
         */
        static let kRobotoRegular: String = "RobotoRegular"
        /**
         * Please Add this fonts Manually
         */
        static let kRobotoItalicBold: String = "RobotoItalic-Bold"
    }
}
