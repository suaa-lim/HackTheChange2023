//
//  AppConstants.swift
//  Suasapplication

import Foundation

struct AppConstants {
    static let serverURL: String = "@{serverURL}"
}
