//
//  SuasapplicationApp.swift
//  Suasapplication

import SwiftUI

@main
struct SuasapplicationApp: App {
    @UIApplicationDelegateAdaptor(AppDelegate.self) var appDelegate

    var body: some Scene {
        WindowGroup {
            WelcomeView()
        }
    }
}
